model ThermalLoop
  // Auto-generated from config/assumptions.json. Simplified lumped model.
  // Two closed circuits coupled by a heat exchanger (effectiveness model).
  parameter Real cp = 4186.0 "water specific heat [J/(kg.K)]";
  parameter Real it_power = 1500000.0 "total IT power [W]";
  parameter Real capture = 0.8 "liquid capture fraction [-]";
  parameter Real hx_eff = 0.85 "heat exchanger effectiveness [-]";
  parameter Real m_pri = 19.1113 "primary mass flow [kg/s]";
  parameter Real m_sec = 19.1113 "secondary mass flow [kg/s]";
  parameter Real tank_mass = 49850.0 "buffer tank water mass [kg]";
  parameter Real tank_loss = 25.0 "tank standing loss [W/K]";
  parameter Real amb = 283.15 "ambient temperature [K]";

  Real q_liquid "captured liquid heat [W]";
  Real q_hx "heat transferred by HX [W]";
  Real T_buffer(start = 318.15) "buffer tank temperature [K]";
equation
  q_liquid = it_power * capture;
  // effectiveness model: transferred heat limited by effectiveness and flows
  q_hx = hx_eff * q_liquid;
  // buffer tank energy balance (charge from HX, standing loss to ambient)
  tank_mass * cp * der(T_buffer) = q_hx - tank_loss * (T_buffer - amb);
annotation(experiment(StartTime = 0, StopTime = 86400, Interval = 600));
end ThermalLoop;
