"""ThermalLoop AI Center - full-scale 1:1 facility generator for Blender.

Open this file in Blender (Scripting tab) and press "Run Script", or run headless:

    blender --background --factory-startup --python blender/generate_facility.py

It builds the complete facility (main building with six separated floors, three
GPU data-center floors, ground-floor robot laboratory, B1 seed storage/testing,
B2 heat-exchanger/pump plant, arched greenhouse, underground hot/cold water
distribution, detailed racks/robots/pumps/tanks/pipes), assigns realistic
glass / metal / concrete / emissive materials and lighting, adds cameras, then
saves an editable project and exports a GLB:

    <project>/blender/thermal_loop.blend
    <project>/frontend/public/models/thermal_loop.glb

The script reads the shared project configuration when available
(config/geometry.json, config/equipment.json) so geometry and stable object
identifiers (e.g. gpu_f1_rack_001, hx_b2_primary_001) stay consistent with the
FastAPI scene and the physics simulation. If the config is not found it falls
back to built-in defaults so the script still runs standalone inside Blender.

Coordinates follow the project convention (X east, Y north, Z up, metres) and
the GLB is exported +Y up to match three.js / React Three Fiber. All existing
ThermalLoop files are preserved; this script only writes the two artifacts above.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

try:
    import bpy  # type: ignore
    import bmesh  # type: ignore
except ImportError:  # pragma: no cover - only importable inside Blender
    bpy = None
    bmesh = None


# ---------------------------------------------------------------------------
# Project paths and configuration
# ---------------------------------------------------------------------------
def project_root() -> Path:
    """Locate the thermal-loop project root whether run from a file or pasted."""
    try:
        here = Path(__file__).resolve()
        if here.parent.name == "blender":
            return here.parents[1]
    except NameError:
        pass
    for candidate in (Path(r"C:\Users\vande\thermal-loop"), Path.cwd(), Path.cwd().parent):
        if (candidate / "config" / "geometry.json").exists():
            return candidate
    return Path(r"C:\Users\vande\thermal-loop")


ROOT = project_root()

DEFAULT_GEOMETRY = {
    "main_building": {"width_x": 36.0, "depth_y": 22.0, "height_z": 18.0,
                      "footprint": {"x": [-18.0, 18.0], "y": [-11.0, 11.0]}},
    "floors": [
        {"id": "b2", "name": "B2 Mechanical Plant", "z": [-8.5, -4.0], "use": "mechanical_plant_heat_exchanger"},
        {"id": "b1", "name": "B1 Seed Storage & Testing", "z": [-4.0, 0.0], "use": "seed_storage_testing"},
        {"id": "gf", "name": "GF Robot Laboratory", "z": [0.0, 4.5], "use": "robot_laboratory"},
        {"id": "f1", "name": "1F GPU Data Center", "z": [4.5, 9.0], "use": "gpu_data_center"},
        {"id": "f2", "name": "2F GPU Data Center", "z": [9.0, 13.5], "use": "gpu_data_center"},
        {"id": "f3", "name": "3F GPU Data Center", "z": [13.5, 18.0], "use": "gpu_data_center"},
    ],
    "greenhouse": {"center": [41.0, 0.0, 0.0], "width_x": 30.0, "depth_y": 18.0, "max_height_z": 5.0,
                   "roof": "arched", "footprint": {"x": [26.0, 56.0], "y": [-9.0, 9.0]}},
    "utility_corridor": {"z": [-3.0, -1.5], "path": [[18.0, 0.0, -2.25], [26.0, 0.0, -2.25]], "width_y": 2.5},
    "gpu_floor_layout": {"racks_per_row": 6, "rack_size": {"width_x": 0.8, "depth_y": 1.2, "height_z": 2.2}},
}

DEFAULT_EQUIPMENT = {
    "heat_exchangers": [{"id": "hx_b2_primary_001", "position": [-6.0, 0.0, -6.25]}],
    "pumps": [
        {"id": "pump_primary_001", "position": [-2.0, -6.0, -6.25]},
        {"id": "pump_secondary_001", "position": [-2.0, -5.0, -6.25]},
        {"id": "pump_greenhouse_001", "position": [18.0, 0.0, -2.25]},
    ],
    "valves": [
        {"id": "valve_primary_iso_001", "position": [-4.5, 1.0, -6.25]},
        {"id": "valve_primary_iso_002", "position": [-4.5, -1.0, -6.25]},
        {"id": "valve_aux_reject_001", "position": [0.0, -3.0, -6.25]},
        {"id": "valve_mix_robot_001", "position": [5.0, 0.0, 1.0]},
        {"id": "valve_mix_seed_store_001", "position": [4.0, -3.0, -2.0]},
        {"id": "valve_mix_seed_test_001", "position": [-4.0, 3.0, -2.0]},
        {"id": "valve_mix_greenhouse_001", "position": [41.0, -6.0, -0.5]},
    ],
    "tanks": [
        {"id": "tank_buffer_001", "type": "thermal_buffer", "position": [6.0, 4.0, -6.25]},
        {"id": "tank_verify_001", "type": "water_treatment_sidestream", "position": [10.0, 4.0, -6.25]},
    ],
    "heat_pump": {"id": "hp_b2_001", "position": [10.0, -5.0, -6.25]},
    "dry_cooler": {"id": "drycooler_roof_001", "position": [0.0, -8.0, 18.8]},
    "power_distribution": [
        {"id": "pdu_f1_001", "position": [14.0, -7.5, 6.75]},
        {"id": "pdu_f2_001", "position": [14.0, -7.5, 11.25]},
        {"id": "pdu_f3_001", "position": [14.0, -7.5, 15.75]},
    ],
    "lab_equipment": [
        {"id": "robot_arm_gf_001", "position": [-10.0, -4.0, 0.3]},
        {"id": "robot_arm_gf_002", "position": [-2.0, -4.0, 0.3]},
        {"id": "robot_arm_gf_003", "position": [6.0, -4.0, 0.3]},
        {"id": "robot_test_cell_gf_001", "position": [10.0, 4.0, 1.2]},
    ],
    "seed_equipment": [
        {"id": "seed_rack_b1_001", "position": [-11.0, -4.0, -2.0]},
        {"id": "seed_rack_b1_002", "position": [-7.0, -4.0, -2.0]},
        {"id": "seed_rack_b1_003", "position": [-11.0, 4.0, -2.0]},
        {"id": "growth_chamber_b1_001", "position": [5.0, -4.0, -2.0]},
        {"id": "growth_chamber_b1_002", "position": [10.0, -4.0, -2.0]},
        {"id": "growth_chamber_b1_003", "position": [5.0, 4.0, -2.0]},
        {"id": "growth_chamber_b1_004", "position": [10.0, 4.0, -2.0]},
    ],
}


def load_json(name, default):
    path = ROOT / "config" / f"{name}.json"
    try:
        with path.open(encoding="utf-8") as fh:
            print(f"[config] loaded {path}")
            return json.load(fh)
    except (FileNotFoundError, json.JSONDecodeError):
        print(f"[config] {path} not found; using built-in defaults")
        return default


# ---------------------------------------------------------------------------
# Material and object helpers (data API - safe headless and in the Blender UI)
# ---------------------------------------------------------------------------
_MATERIALS = {}


def material(name, color, *, metallic=0.0, roughness=0.6, alpha=1.0, emission=0.0):
    if name in _MATERIALS:
        return _MATERIALS[name]
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    bsdf = next((n for n in nodes if n.type == "BSDF_PRINCIPLED"), None)
    if bsdf is None:
        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        output = next((n for n in nodes if n.type == "OUTPUT_MATERIAL"), None) or nodes.new("ShaderNodeOutputMaterial")
        mat.node_tree.links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    r, g, b = color

    def set_input(key, value):
        if key in bsdf.inputs:
            bsdf.inputs[key].default_value = value

    set_input("Base Color", (r, g, b, 1.0))
    set_input("Metallic", metallic)
    set_input("Roughness", roughness)
    set_input("Emission Color", (r, g, b, 1.0))
    set_input("Emission Strength", emission)
    if alpha < 1.0:
        set_input("Alpha", alpha)
        try:
            mat.blend_method = "BLEND"
        except (AttributeError, TypeError):
            pass
    _MATERIALS[name] = mat
    return mat


def clear_scene():
    for obj in list(bpy.data.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    for block in (bpy.data.meshes, bpy.data.curves, bpy.data.materials,
                  bpy.data.cameras, bpy.data.lights, bpy.data.collections):
        for item in list(block):
            try:
                block.remove(item)
            except RuntimeError:
                pass
    _MATERIALS.clear()


def get_collection(name):
    if name in bpy.data.collections:
        return bpy.data.collections[name]
    coll = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(coll)
    return coll


def _add(name, mesh, coll):
    obj = bpy.data.objects.new(name, mesh)
    coll.objects.link(obj)
    return obj


def group_empty(name, location, coll, children):
    """Create an empty carrying the stable id, parenting the detail meshes.

    A raycast on any child still resolves to this id in the viewer, so grouped
    assets (pumps, robot arms) remain selectable by their engineering id.
    """
    empty = bpy.data.objects.new(name, None)
    empty.empty_display_size = 0.4
    empty.location = tuple(location)
    coll.objects.link(empty)
    for child in children:
        child.parent = empty
    return empty


def box(name, center, size, mat, coll):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bm.to_mesh(mesh)
    bm.free()
    obj = _add(name, mesh, coll)
    obj.location = tuple(center)
    obj.scale = (max(size[0], 1e-3), max(size[1], 1e-3), max(size[2], 1e-3))
    obj.data.materials.append(mat)
    return obj


def cyl(name, center, radius, depth, mat, coll, axis="Z", segments=24):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=segments,
                          radius1=radius, radius2=radius, depth=depth)
    bm.to_mesh(mesh)
    bm.free()
    obj = _add(name, mesh, coll)
    obj.location = tuple(center)
    if axis == "X":
        obj.rotation_euler = (0.0, math.pi / 2.0, 0.0)
    elif axis == "Y":
        obj.rotation_euler = (math.pi / 2.0, 0.0, 0.0)
    obj.data.materials.append(mat)
    return obj


def sphere(name, center, radius, mat, coll):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=16, v_segments=12, radius=radius)
    bm.to_mesh(mesh)
    bm.free()
    obj = _add(name, mesh, coll)
    obj.location = tuple(center)
    obj.data.materials.append(mat)
    return obj


def pipe(name, points, radius, mat, coll):
    curve = bpy.data.curves.new(f"{name}_curve", type="CURVE")
    curve.dimensions = "3D"
    spline = curve.splines.new("POLY")
    spline.points.add(len(points) - 1)
    for i, (x, y, z) in enumerate(points):
        spline.points[i].co = (x, y, z, 1.0)
    curve.bevel_depth = radius
    curve.bevel_resolution = 3
    obj = bpy.data.objects.new(name, curve)
    coll.objects.link(obj)
    obj.data.materials.append(mat)
    return obj


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------
def build_structure(geom, coll):
    building = geom["main_building"]
    w, d, h = building["width_x"], building["depth_y"], building["height_z"]
    glass = material("glass", (0.52, 0.74, 0.82), metallic=0.0, roughness=0.08, alpha=0.22)
    concrete = material("concrete", (0.34, 0.37, 0.41), roughness=0.85)
    steel = material("steel", (0.42, 0.47, 0.52), metallic=0.9, roughness=0.3)
    walkway = material("walkway", (0.55, 0.6, 0.64), metallic=0.3, roughness=0.5)

    floor_use = {f["id"]: f["use"] for f in geom["floors"]}
    for floor in geom["floors"]:
        z0, z1 = floor["z"]
        story = z1 - z0
        fid = floor["id"]
        box(f"slab_{fid}", [0, 0, z0 + 0.14], [w, d, 0.28], concrete, coll)
        for gx in (-17.3, -8.65, 0.0, 8.65, 17.3):
            for gy in (-10.3, 0.0, 10.3):
                box(f"column_{fid}_{gx:+.0f}_{gy:+.0f}", [gx, gy, z0 + story / 2.0],
                    [0.3, 0.3, story], steel, coll)
        box(f"beam_{fid}_n", [0, 10.6, z1 - 0.2], [w - 0.4, 0.35, 0.35], steel, coll)
        box(f"beam_{fid}_s", [0, -10.6, z1 - 0.2], [w - 0.4, 0.35, 0.35], steel, coll)
        box(f"walkway_{fid}", [0, 0, z0 + 0.32], [w - 4, 0.08,
            2.2 if floor_use[fid] == "gpu_data_center" else 1.5], walkway, coll)
        if z1 <= 0:
            box(f"wall_{fid}_e", [w / 2, 0, z0 + story / 2], [0.3, d, story], concrete, coll)
            box(f"wall_{fid}_w", [-w / 2, 0, z0 + story / 2], [0.3, d, story], concrete, coll)
            box(f"wall_{fid}_n", [0, d / 2, z0 + story / 2], [w, 0.3, story], concrete, coll)
            box(f"wall_{fid}_s", [0, -d / 2, z0 + story / 2], [w, 0.3, story], concrete, coll)

    for level in range(4):
        zc = 2.25 + level * 4.5
        box(f"glass_north_{level}", [0, d / 2, zc], [w, 0.1, 4.4], glass, coll)
        box(f"glass_south_{level}", [0, -d / 2, zc], [w, 0.1, 4.4], glass, coll)
        box(f"glass_east_{level}", [w / 2, 0, zc], [0.1, d, 4.4], glass, coll)
        box(f"glass_west_{level}", [-w / 2, 0, zc], [0.1, d, 4.4], glass, coll)
    box("roof_slab", [0, 0, h + 0.12], [w + 0.4, d + 0.4, 0.24], concrete, coll)

    ground = material("ground", (0.17, 0.22, 0.16), roughness=0.95)
    box("ground_plane", [19, 0, -0.06], [120, 70, 0.12], ground, coll)


def build_gpu_floors(geom, coll):
    layout = geom["gpu_floor_layout"]
    rack = layout["rack_size"]
    per_row = layout["racks_per_row"]
    floor_z = {f["id"]: f["z"] for f in geom["floors"]}
    enclosure = material("rack_enclosure", (0.09, 0.12, 0.16), metallic=0.8, roughness=0.3)
    blade = material("gpu_blade", (0.15, 0.23, 0.29), metallic=0.7, roughness=0.35)
    led = material("gpu_led", (0.2, 0.7, 1.0), emission=5.0)
    supply = material("pipe_cold", (0.16, 0.56, 0.91), metallic=0.5, roughness=0.3)
    ret = material("pipe_hot", (0.9, 0.3, 0.27), metallic=0.5, roughness=0.3)

    for fid in ("f1", "f2", "f3"):
        z0 = floor_z[fid][0]
        for index in range(12):
            row, col = divmod(index, per_row)
            x = -14.0 + col * (rack["width_x"] + 2.0)
            y = -4.0 + row * 8.0
            z = z0 + 0.35 + rack["height_z"] / 2.0
            rid = f"gpu_{fid}_rack_{index + 1:03d}"
            box(rid, [x, y, z], [rack["width_x"], rack["depth_y"], rack["height_z"]], enclosure, coll)
            for b in range(9):
                bz = z - rack["height_z"] / 2 + 0.3 + b * 0.2
                box(f"{rid}_blade_{b + 1:02d}", [x, y + rack["depth_y"] / 2, bz],
                    [rack["width_x"] * 0.86, 0.04, 0.15], blade, coll)
                box(f"{rid}_led_{b + 1:02d}", [x - 0.26, y + rack["depth_y"] / 2 + 0.02, bz],
                    [0.07, 0.03, 0.04], led, coll)
            cyl(f"{rid}_supply_tap", [x + 0.31, y - rack["depth_y"] / 2, z], 0.035, 1.85, supply, coll)
            cyl(f"{rid}_return_tap", [x - 0.31, y - rack["depth_y"] / 2, z], 0.035, 1.85, ret, coll)
        cyl(f"manifold_supply_{fid}_001", [-14.0, -6.0, z0 + 0.9], 0.12, 24, supply, coll, axis="X")
        cyl(f"manifold_return_{fid}_001", [14.0, 6.0, z0 + 0.9], 0.12, 24, ret, coll, axis="X")


def build_power_distribution(equip, coll):
    pdu_mat = material("pdu", (0.19, 0.23, 0.26), metallic=0.78, roughness=0.3)
    for pdu in equip.get("power_distribution", DEFAULT_EQUIPMENT["power_distribution"]):
        box(pdu["id"], pdu["position"], [1.8, 1.0, 2.4], pdu_mat, coll)


def build_robot_lab(equip, coll):
    arm_mat = material("robot_arm", (0.96, 0.65, 0.16), metallic=0.6, roughness=0.3)
    joint_mat = material("robot_joint", (0.12, 0.16, 0.2), metallic=0.85, roughness=0.3)
    bench_mat = material("workbench", (0.45, 0.5, 0.55), metallic=0.5, roughness=0.45)
    for item in equip.get("lab_equipment", DEFAULT_EQUIPMENT["lab_equipment"]):
        px, py, pz = item["position"]
        if "robot_arm" in item["id"]:
            parts = [
                cyl(f"{item['id']}_base", [px, py, pz + 0.15], 0.6, 0.3, joint_mat, coll),
                cyl(f"{item['id']}_lower", [px, py, pz + 1.0], 0.22, 1.5, arm_mat, coll),
                sphere(f"{item['id']}_elbow", [px, py, pz + 1.8], 0.28, joint_mat, coll),
                cyl(f"{item['id']}_upper", [px + 0.4, py, pz + 2.3], 0.16, 1.1, arm_mat, coll, axis="X"),
                box(f"{item['id']}_gripper", [px + 0.95, py, pz + 2.3], [0.3, 0.1, 0.25], joint_mat, coll),
            ]
            group_empty(item["id"], item["position"], coll, parts)
        else:
            box(item["id"], item["position"], [2.2, 2.2, 2.4], bench_mat, coll)
    for i, wx in enumerate((-12, -4, 4, 12)):
        box(f"workstation_gf_{i + 1:03d}", [wx, -5.2, 0.9], [3.0, 1.3, 0.1], bench_mat, coll)


def build_seed_facility(equip, coll):
    rack_mat = material("seed_rack", (0.5, 0.55, 0.6), metallic=0.6, roughness=0.4)
    chamber_mat = material("growth_chamber", (0.83, 0.87, 0.88), metallic=0.5, roughness=0.3)
    glow = material("chamber_glow", (0.4, 0.95, 0.75), emission=3.0)
    for item in equip.get("seed_equipment", DEFAULT_EQUIPMENT["seed_equipment"]):
        px, py, pz = item["position"]
        if "seed_rack" in item["id"]:
            box(item["id"], item["position"], [1.8, 1.0, 2.4], rack_mat, coll)
            for s in range(4):
                box(f"{item['id']}_shelf_{s + 1}", [px, py, pz - 1.0 + s * 0.6],
                    [1.7, 0.9, 0.05], rack_mat, coll)
        else:
            box(item["id"], item["position"], [2.0, 1.2, 2.4], chamber_mat, coll)
            box(f"{item['id']}_light", [px, py + 0.62, pz], [1.4, 0.04, 1.6], glow, coll)


def build_mechanical_plant(equip, coll):
    hx_mat = material("hx_plate", (0.46, 0.5, 0.55), metallic=0.85, roughness=0.25)
    pump_mat = material("pump", (0.2, 0.5, 0.67), metallic=0.75, roughness=0.3)
    motor_mat = material("pump_motor", (0.27, 0.31, 0.35), metallic=0.85, roughness=0.3)
    valve_mat = material("valve", (0.8, 0.63, 0.21), metallic=0.8, roughness=0.25)
    buffer_mat = material("tank_buffer", (0.27, 0.56, 0.68), metallic=0.75, roughness=0.3)
    verify_mat = material("tank_verify", (0.48, 0.57, 0.62), metallic=0.75, roughness=0.3)
    hp_mat = material("heat_pump", (0.6, 0.29, 0.43), metallic=0.7, roughness=0.3)
    cooler_mat = material("dry_cooler", (0.29, 0.35, 0.39), metallic=0.7, roughness=0.3)

    for hx in equip.get("heat_exchangers", DEFAULT_EQUIPMENT["heat_exchangers"]):
        px, py, pz = hx["position"]
        box(hx["id"], [px, py, pz], [2.4, 1.2, 2.4], hx_mat, coll)
        for i in range(12):
            box(f"{hx['id']}_plate_{i + 1:02d}", [px - 1.0 + i * 0.17, py, pz], [0.05, 1.1, 2.3], hx_mat, coll)
    for p in equip.get("pumps", DEFAULT_EQUIPMENT["pumps"]):
        px, py, pz = p["position"]
        parts = [
            cyl(f"{p['id']}_volute", [px, py, pz], 0.48, 0.75, pump_mat, coll, axis="Y"),
            cyl(f"{p['id']}_motor", [px + 0.7, py, pz], 0.32, 0.9, motor_mat, coll, axis="X"),
        ]
        group_empty(p["id"], p["position"], coll, parts)
    for v in equip.get("valves", DEFAULT_EQUIPMENT["valves"]):
        sphere(v["id"], v["position"], 0.28, valve_mat, coll)
    for t in equip.get("tanks", DEFAULT_EQUIPMENT["tanks"]):
        mat = buffer_mat if t.get("type") == "thermal_buffer" else verify_mat
        r, dz = (1.7, 3.2) if t.get("type") == "thermal_buffer" else (1.15, 2.8)
        cyl(t["id"], t["position"], r, dz, mat, coll)
    hp = equip.get("heat_pump", DEFAULT_EQUIPMENT["heat_pump"])
    box(hp["id"], hp["position"], [2.8, 1.8, 2.2], hp_mat, coll)
    dc = equip.get("dry_cooler", DEFAULT_EQUIPMENT["dry_cooler"])
    box(dc["id"], dc["position"], [5.0, 2.2, 1.4], cooler_mat, coll)


def build_underground_distribution(geom, coll):
    corridor = geom["utility_corridor"]
    p0, p1 = corridor["path"]
    cx = (p0[0] + p1[0]) / 2.0
    length = abs(p1[0] - p0[0])
    z0, z1 = corridor["z"]
    concrete = material("corridor", (0.41, 0.45, 0.48), roughness=0.9)
    cold = material("pipe_cold", (0.16, 0.56, 0.91), metallic=0.5, roughness=0.3)
    hot = material("pipe_hot", (0.9, 0.3, 0.27), metallic=0.5, roughness=0.3)

    box("corridor_underground", [cx, 0.0, (z0 + z1) / 2.0], [length, corridor["width_y"], z1 - z0 - 0.3], concrete, coll)
    pipe("pipe_buried_supply_001", [[6, 4, -6.0], [16, -0.6, -2.25], [26, -0.6, -2.25], [41, -6.0, -0.5]], 0.05, hot, coll)
    pipe("pipe_buried_return_001", [[41, 0.6, -0.5], [26, 0.6, -2.25], [16, 0.6, -2.25], [-2, -5, -6.0]], 0.05, cold, coll)
    pipe("pipe_pri_supply_001", [[-2, -6, -6.25], [-14, -6, -6.25], [-14, -6, 15.75]], 0.075, cold, coll)
    pipe("pipe_pri_return_001", [[14, 6, 15.75], [14, 6, -6.25], [-6, 1, -6.25]], 0.075, hot, coll)


def build_greenhouse(geom, coll):
    gh = geom["greenhouse"]
    cx, cy = gh["center"][0], gh["center"][1]
    half_w, half_d = gh["width_x"] / 2.0, gh["depth_y"] / 2.0
    eave, peak = 2.35, gh["max_height_z"]
    glass = material("greenhouse_glass", (0.66, 0.88, 0.8), roughness=0.1, alpha=0.22)
    soil = material("soil", (0.33, 0.25, 0.18), roughness=0.95)
    plant = material("plant", (0.3, 0.6, 0.25), roughness=0.8)
    hot = material("pipe_hot", (0.9, 0.3, 0.27), metallic=0.5, roughness=0.3)

    box("greenhouse_wall_west", [cx - half_w, cy, eave / 2], [0.1, gh["depth_y"], eave], glass, coll)
    box("greenhouse_wall_east", [cx + half_w, cy, eave / 2], [0.1, gh["depth_y"], eave], glass, coll)
    box("greenhouse_wall_south", [cx, cy - half_d, eave / 2], [gh["width_x"], 0.1, eave], glass, coll)
    box("greenhouse_wall_north", [cx, cy + half_d, eave / 2], [gh["width_x"], 0.1, eave], glass, coll)

    roof_mesh = bpy.data.meshes.new("greenhouse_roof")
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=False, cap_tris=False, segments=48,
                          radius1=half_w, radius2=half_w, depth=gh["depth_y"])
    bm.to_mesh(roof_mesh)
    bm.free()
    roof = _add("greenhouse_roof", roof_mesh, coll)
    roof.location = (cx, cy, eave)
    roof.rotation_euler = (math.pi / 2.0, 0.0, 0.0)
    roof.scale = (1.0, 1.0, (peak - eave) / half_w)
    roof.data.materials.append(glass)

    for i in range(6):
        bx = cx - 10.0 + (i % 3) * 10.0
        by = cy - 4.0 + (i // 3) * 8.0
        box(f"bed_greenhouse_{i + 1:03d}", [bx, by, 0.25], [8.0, 6.0, 0.5], soil, coll)
        pipe(f"pipe_soil_heat_{i + 1:03d}",
             [[bx - 3, by - 2, 0.1], [bx + 3, by - 2, 0.1], [bx + 3, by, 0.1],
              [bx - 3, by, 0.1], [bx - 3, by + 2, 0.1], [bx + 3, by + 2, 0.1]], 0.03, hot, coll)
        for p in range(12):
            px = bx - 3.0 + (p % 4) * 2.0
            py = by - 2.0 + (p // 4) * 2.0
            cyl(f"plant_gh_{i + 1:02d}_{p + 1:02d}", [px, py, 0.75], 0.08, 0.5, plant, coll)


# ---------------------------------------------------------------------------
# Lighting and cameras
# ---------------------------------------------------------------------------
def build_lighting(coll):
    sun_data = bpy.data.lights.new("sun", type="SUN")
    sun_data.energy = 3.2
    sun = bpy.data.objects.new("key_sun", sun_data)
    sun.rotation_euler = (math.radians(55), math.radians(18), math.radians(40))
    coll.objects.link(sun)

    world = bpy.context.scene.world or bpy.data.worlds.new("World")
    bpy.context.scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg:
        bg.inputs["Color"].default_value = (0.62, 0.72, 0.8, 1.0)
        bg.inputs["Strength"].default_value = 0.8

    for z in (-6.25, -2.0, 2.25, 6.75, 11.25, 15.75):
        light = bpy.data.lights.new(f"fill_{z:+.0f}", type="AREA")
        light.energy = 1800
        light.size = 20
        obj = bpy.data.objects.new(f"fill_light_{z:+.0f}", light)
        obj.location = (0, 0, z + 1.8)
        coll.objects.link(obj)


def build_cameras(geom, coll):
    building = geom["main_building"]
    gh = geom["greenhouse"]
    site_cx = (building["footprint"]["x"][0] + gh["footprint"]["x"][1]) / 2.0

    def add_camera(name, location, target):
        cam_data = bpy.data.cameras.new(name)
        cam_data.lens = 35
        cam = bpy.data.objects.new(name, cam_data)
        cam.location = location
        dx, dy, dz = (target[0] - location[0], target[1] - location[1], target[2] - location[2])
        yaw = math.atan2(dx, -dy)
        pitch = math.atan2(math.hypot(dx, dy), -dz)
        cam.rotation_euler = (pitch, 0.0, yaw)
        coll.objects.link(cam)
        return cam

    iso = add_camera("camera_isometric", (site_cx + 55, -55, 42), (site_cx - 6, 0, 6))
    add_camera("camera_front_cutaway", (6, -70, 9), (6, 0, 7))
    add_camera("camera_greenhouse", (gh["center"][0] - 24, -26, 16), (gh["center"][0], 0, 2.5))
    bpy.context.scene.camera = iso


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
def save_and_export():
    blend_path = ROOT / "blender" / "thermal_loop.blend"
    glb_dir = ROOT / "frontend" / "public" / "models"
    glb_dir.mkdir(parents=True, exist_ok=True)
    glb_path = glb_dir / "thermal_loop.glb"

    bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
    print(f"[save] editable project -> {blend_path}")

    bpy.ops.export_scene.gltf(
        filepath=str(glb_path),
        export_format="GLB",
        export_yup=True,
        use_active_collection=False,
        export_apply=True,
        export_cameras=True,
        export_lights=True,
    )
    print(f"[export] GLB -> {glb_path} ({glb_path.stat().st_size} bytes)", flush=True)


def build_all():
    geom = load_json("geometry", DEFAULT_GEOMETRY)
    equip = load_json("equipment", DEFAULT_EQUIPMENT)
    clear_scene()

    build_structure(geom, get_collection("01_structure"))
    build_gpu_floors(geom, get_collection("02_gpu_data_center"))
    build_power_distribution(equip, get_collection("02_gpu_data_center"))
    build_robot_lab(equip, get_collection("03_robot_laboratory"))
    build_seed_facility(equip, get_collection("04_seed_facility"))
    build_mechanical_plant(equip, get_collection("05_mechanical_plant"))
    build_underground_distribution(geom, get_collection("06_underground_distribution"))
    build_greenhouse(geom, get_collection("07_greenhouse"))
    build_lighting(get_collection("08_lighting"))
    build_cameras(geom, get_collection("09_cameras"))

    for engine in ("BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"):
        try:
            bpy.context.scene.render.engine = engine
            break
        except (TypeError, AttributeError):
            continue


def main():
    if bpy is None:
        print("Run this inside Blender: open it in the Scripting tab and press Run Script,")
        print("or: blender --background --factory-startup --python blender/generate_facility.py")
        return 1
    print(f"[ThermalLoop] project root: {ROOT}")
    build_all()
    total = sum(1 for obj in bpy.data.objects if obj.type in {"MESH", "CURVE"})
    print(f"[ThermalLoop] authored {total} facility objects")
    save_and_export()
    print("[ThermalLoop] done. Open thermal_loop.blend or load the GLB in the viewer.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
