"""Run reproducible project validation (backend, scene contract, TS, Vite build)."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend"


def run(label: str, command: list[str], cwd: Path) -> dict:
    completed = subprocess.run(command, cwd=cwd, capture_output=True, text=True)
    output = (completed.stdout + completed.stderr).strip()
    if completed.returncode != 0:
        print(f"\n[{label}] FAILED\n{output}")
        raise SystemExit(completed.returncode)
    print(f"[{label}] PASS")
    if output:
        print(output)
    return {"label": label, "passed": True}


def main() -> None:
    checks = []
    checks.append(run(
        "Python tests",
        [sys.executable, "-m", "pytest", "tests", "-q"],
        ROOT,
    ))
    checks.append(run(
        "TypeScript",
        ["node", "node_modules/typescript/lib/tsc.js", "--noEmit", "-p", "tsconfig.json"],
        FRONTEND,
    ))
    checks.append(run(
        "Vite production build",
        ["node", "node_modules/vite/bin/vite.js", "build"],
        FRONTEND,
    ))

    sys.path.insert(0, str(ROOT / "backend"))
    from thermalloop.config_loader import load_config
    from thermalloop.scene import build_scene
    from thermalloop.simulation import run_simulation

    config = load_config()
    scene = build_scene(config)
    result = run_simulation({"duration_s": 3600, "timestep_s": 600}, config)
    first = result["series"][0]
    contract = {
        "six_floors": scene["counts"]["floors"] == 6,
        "greenhouse_30x18x5": (
            config["geometry"]["greenhouse"]["width_x"],
            config["geometry"]["greenhouse"]["depth_y"],
            config["geometry"]["greenhouse"]["max_height_z"],
        ) == (30.0, 18.0, 5.0),
        "all_pipe_paths_renderable": all(len(pipe["points"]) >= 2 for pipe in scene["pipes"]),
        "all_pipe_states_bound": set(first["pipe_states"]) == {pipe["id"] for pipe in scene["pipes"]},
        "all_balances_pass": all(
            value["passed"] for value in result["conservation_checks"].values()
            if isinstance(value, dict) and "passed" in value
        ),
        "not_measured_data": result["is_measured_data"] is False,
    }
    if not all(contract.values()):
        print(json.dumps(contract, indent=2))
        raise SystemExit("Scene/simulation contract validation failed")
    checks.append({"label": "Scene/simulation contract", "passed": True, **contract})
    print("[Scene/simulation contract] PASS")
    report = {
        "checks": checks,
        "scene_counts": scene["counts"],
        "result_mode": result["mode"],
    }
    (ROOT / "results" / "validation-report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
