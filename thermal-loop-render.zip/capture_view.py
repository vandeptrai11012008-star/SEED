"""Capture one camera preset through a real headless Chromium WebGL session.

Usage: python tests/capture_view.py underground data/view-underground.png
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from urllib.parse import urlencode

PORT = os.environ.get("THERMALLOOP_WEB_PORT", "5173")

ROOT = Path(__file__).resolve().parents[1]
BROWSERS = [
    Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
    Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
]


def main() -> None:
    view = sys.argv[1] if len(sys.argv) > 1 else "auto_fit"
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "data" / f"view-{view}.png"
    floor = sys.argv[3] if len(sys.argv) > 3 else None
    browser = next((candidate for candidate in BROWSERS if candidate.exists()), None)
    if browser is None:
        raise SystemExit("Chrome or Edge not found")
    query = {"view": view}
    if floor:
        query["floor"] = floor
    for extra in sys.argv[4:]:
        if "=" in extra:
            key, value = extra.split("=", 1)
            query[key] = value
    url = f"http://127.0.0.1:{PORT}/?{urlencode(query)}"
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    profile = tempfile.mkdtemp(prefix=f"thermalloop-{view}-")
    try:
        command = [
            str(browser), "--headless=new", "--no-first-run", "--disable-extensions",
            "--ignore-gpu-blocklist", "--enable-webgl", "--use-angle=swiftshader",
            "--window-size=1600,1000", "--virtual-time-budget=12000",
            f"--user-data-dir={profile}", f"--screenshot={output}", url,
        ]
        completed = subprocess.run(command, capture_output=True, text=True, timeout=60)
        if not output.exists():
            raise RuntimeError(
                f"Browser did not create screenshot (exit {completed.returncode})\n"
                f"stdout: {completed.stdout}\nstderr: {completed.stderr}"
            )
        print(f"Captured {view}: {output} ({output.stat().st_size} bytes)")
    finally:
        shutil.rmtree(profile, ignore_errors=True)


if __name__ == "__main__":
    main()
