# Start the ThermalLoop FastAPI backend.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location "$root\backend"
Write-Host "Starting backend on http://127.0.0.1:8000 (docs at /docs)" -ForegroundColor Cyan
python run_server.py
