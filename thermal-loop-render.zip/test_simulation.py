"""Simulation engine tests, including numerical conservation validation."""
import math

from thermalloop.config_loader import load_config, expand_rack_ids
from thermalloop.simulation import run_simulation, SimplifiedPhysicsEngine


def test_run_produces_series():
    res = run_simulation({"mode": "simplified_physics", "duration_s": 86400, "timestep_s": 600})
    assert res["mode"] == "simplified_physics"
    assert res["is_measured_data"] is False
    assert res["n_steps"] == 144
    assert len(res["series"]) == 144


def test_capture_split_conservation():
    res = run_simulation({"mode": "simplified_physics", "duration_s": 86400, "timestep_s": 600})
    c = res["conservation_checks"]["capture_split"]
    assert c["passed"], c


def test_primary_balance_conservation():
    res = run_simulation({"mode": "simplified_physics", "duration_s": 86400, "timestep_s": 600})
    c = res["conservation_checks"]["primary_balance"]
    assert c["passed"], c


def test_secondary_balance_conservation():
    res = run_simulation({"mode": "simplified_physics", "duration_s": 86400, "timestep_s": 600})
    c = res["conservation_checks"]["secondary_balance"]
    assert c["passed"], c


def test_per_step_residual_small():
    res = run_simulation({"mode": "simplified_physics", "duration_s": 86400, "timestep_s": 600})
    for r in res["series"]:
        # secondary header balance residual must be numerically ~0
        assert abs(r["energy_residual_W"]) < 1e-3, r


def test_capture_fraction_respected():
    res = run_simulation({
        "mode": "simplified_physics", "duration_s": 3600, "timestep_s": 600,
        "liquid_capture_fraction": 0.8,
    })
    for r in res["series"]:
        if r["it_power_W"] > 0:
            frac = r["liquid_captured_W"] / r["it_power_W"]
            assert math.isclose(frac, 0.8, rel_tol=1e-9)


def test_full_load_numbers_match_spec():
    # At 100% load: captured = 1200 kW, remaining = 300 kW for default 1500 kW / 0.8
    eng = SimplifiedPhysicsEngine()
    res = eng.run({
        "duration_s": 600, "timestep_s": 600,
        "gpu_load_base_fraction": 1.0, "gpu_load_peak_fraction": 1.0,
    })
    r = res["series"][0]
    assert math.isclose(r["it_power_W"], 1_500_000.0, rel_tol=1e-6)
    assert math.isclose(r["liquid_captured_W"], 1_200_000.0, rel_tol=1e-6)
    assert math.isclose(r["air_remaining_W"], 300_000.0, rel_tol=1e-6)


def test_heat_pump_disabled_scenario():
    res = run_simulation({
        "mode": "simplified_physics", "duration_s": 3600, "timestep_s": 600,
        "overrides": {"controls.heat_pump_enabled": False},
    })
    for r in res["series"]:
        assert r["heat_pump_thermal_W"] == 0.0


def test_external_modes_not_executed():
    for mode in ("openmodelica", "energyplus", "coupled"):
        res = run_simulation({"mode": mode})
        assert res["executed"] is False
        assert res["is_measured_data"] is False


def test_rack_ids_match_contract():
    cfg = load_config()
    racks = expand_rack_ids(cfg)
    ids = {r["id"] for r in racks}
    assert "gpu_f1_rack_001" in ids
    assert "gpu_f2_rack_001" in ids
    assert "gpu_f3_rack_001" in ids
    assert len(racks) == 36  # 3 floors x 12
    # total nominal power = 1500 kW
    assert math.isclose(sum(r["nominal_power_kW"] for r in racks), 1500.0, rel_tol=1e-3)
