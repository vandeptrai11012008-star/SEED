"""GPU scheduling / heat-recovery optimization over the simplified backend.

Pure-Python grid/greedy optimizer (no heavy deps). It sweeps control knobs and
scores each candidate against an objective that rewards delivered recovered heat
and penalizes auxiliary rejection and pump + heat-pump electricity.

Run: python optimization/optimize.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from thermalloop.simulation import run_simulation  # noqa: E402


def objective(result: dict) -> float:
    s = result["summary"]
    recovered = s["total_recovered_kWh"]
    rejected = s["total_aux_rejected_kWh"]
    pump = s["total_pump_elec_kWh"]
    hp = s["total_heat_pump_elec_kWh"]
    # maximize recovered heat, penalize waste and parasitic electricity
    return recovered - 0.1 * rejected - 1.0 * (pump + hp)


def sweep() -> list[dict]:
    candidates = []
    for capture in (0.70, 0.80, 0.90):
        for base in (0.45, 0.55, 0.65):
            for hp_on in (True, False):
                req = {
                    "mode": "simplified_physics",
                    "duration_s": 86400,
                    "timestep_s": 600,
                    "liquid_capture_fraction": capture,
                    "gpu_load_base_fraction": base,
                    "overrides": {"controls.heat_pump_enabled": hp_on},
                }
                res = run_simulation(req)
                candidates.append(
                    {
                        "capture": capture,
                        "base_load": base,
                        "heat_pump": hp_on,
                        "score": round(objective(res), 2),
                        "recovered_kWh": round(res["summary"]["total_recovered_kWh"], 1),
                        "rejected_kWh": round(res["summary"]["total_aux_rejected_kWh"], 1),
                        "all_checks_pass": all(
                            res["conservation_checks"][k]["passed"]
                            for k in ("capture_split", "primary_balance", "secondary_balance")
                        ),
                    }
                )
    return sorted(candidates, key=lambda c: c["score"], reverse=True)


def main():
    ranked = sweep()
    best = ranked[0]
    print(f"Evaluated {len(ranked)} candidates. Best:")
    for k, v in best.items():
        print(f"  {k}: {v}")
    print("\nTop 5:")
    for c in ranked[:5]:
        print(f"  score={c['score']:>8}  capture={c['capture']}  base={c['base_load']}  hp={c['heat_pump']}")


if __name__ == "__main__":
    main()
