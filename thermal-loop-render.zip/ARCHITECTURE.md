# Architecture

## Layers

```
          config/ (shared JSON data contract — single source of truth)
                 |                         |                    |
         backend (Python/FastAPI)    frontend (R3F)     adapters (blender,
         simplified-physics engine   3D + dashboards     modelica, energyplus,
                 |                         ^              optimization)
                 |  REST /api/*            |
                 +-------------------------+
```

The `config/` directory is authoritative. The backend loads it, the frontend
fetches it via `/api/config` and `/api/scene`, and the external adapters read it
to parameterize generated solver inputs. Stable identifiers (floors, racks,
pumps, valves, pipes, heat exchangers, tanks, zones, sensors) are defined once
in config and reused everywhere so 3D objects, API responses, and simulation
outputs line up.

## Exchangeable simulation backend

`backend/thermalloop/simulation.py` defines a single request/result contract.
`run_simulation(request)` dispatches on `mode`:

- `simplified_physics` — deterministic reduced-order engineering baseline with explicit numerical balance checks (default).
- `openmodelica` / `energyplus` / `coupled` — input-generation scaffolds only.
  They return `executed: false`; this repository does not yet import external
  result files. A future solver adapter must execute the tool and parse its
  output before it may report one of these modes as executed. This keeps the UI
  usable without fabricating external-solver data.

## Backend data flow (simplified_physics)

1. GPU workload fraction (diurnal) × total IT power → IT heat.
2. Capture split: `liquid = IT × capture_fraction`, `air = IT − liquid`.
3. Primary flow is sized from captured heat/design ΔT and capped by pump
   rating; return temperature follows `Q = m·cp·ΔT`.
4. HX effectiveness computes both primary and secondary outlet temperatures.
5. A series heat pump may lift the secondary temperature; condenser heat equals
   primary-source extraction plus compressor electricity.
6. The rated dry cooler rejects remaining primary heat; any capacity shortfall
   is exposed as `primary_unrejected_W`, never silently discarded.
7. Temperature-dependent zone and greenhouse-soil demands are computed.
8. Secondary heat is distributed through temperature-qualified branches;
   buried/indoor losses, actual buffer charge/discharge, unmet demand and zone
   temperatures are advanced explicitly.
9. Darcy-Weisbach pressure losses drive pump power. Every scene pipe/sensor/rack
   ID receives a corresponding timestep state.
10. Independent whole-run energy ledgers and closed-loop mass residuals are
    checked (see PHYSICS.md).

## Frontend

- `three/Architecture.tsx`, `ServerHall.tsx`, `InteriorEquipment.tsx`, and
  `Greenhouse.tsx` form a layered, replaceable procedural facility model: PBR
  structure/glass, six-floor cutaway, detailed racks, robots, seed chambers,
  mechanical plant, two tanks, and arched greenhouse vegetation.
- `three/Hydronics.tsx` renders all config-defined pipe polylines as tubes and
  animates flow particles using per-ID simulation temperature/mass flow.
- `three/CameraRig.tsx` provides auto-fit, isometric, front cutaway, WASD
  walkthrough, per-floor, greenhouse and underground views with smooth motion.
- `store.ts` (Zustand) holds config, scene, run, timeline and viewer state.
- `ui/` displays heat recovery, explicit undelivered-energy destinations,
  hydronic operating point, zone temperature/demand/delivery, water
  temperatures, storage, conservation checks, and JSON/CSV export.

## Testing & validation

`tests/` contains 38 passing physics, API, conservation and digital-twin
contract tests. `tests/smoke_upgrade.py` validates a live frontend/backend pair,
including complete pipe-state binding. `scripts/validate_all.py` runs pytest,
TypeScript, the production build and offline scene contract checks. Headless
Chromium screenshots verify actual WebGL framing for auto-fit, front cutaway,
greenhouse, floor, walkthrough and underground presets.
