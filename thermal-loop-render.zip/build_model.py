"""Author the full-scale ThermalLoop facility in Blender and export GLB.

Run headless (Blender must be installed locally):

    blender --background --python blender/build_model.py -- --out data/thermalloop.glb

The model is built entirely from the shared configuration contract
(config/geometry.json, equipment.json, network.json) so Blender geometry stays
consistent with the FastAPI scene and the simulation identifiers. Every object
keeps its stable engineering id (e.g. gpu_f1_rack_001, hx_b2_primary_001,
pipe_pri_supply_001) so the exported GLB can later replace procedural meshes in
the React/Three.js viewer without changing the simulation architecture.

The GLB is exported with +Y up and -Z forward, matching three.js and the
frontend's world->three mapping (world X east, Y north, Z up ->
three x=X, y=Z, z=-Y). This script is never executed by the backend.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

try:
    import bpy  # type: ignore
    import bmesh  # type: ignore
except ImportError:  # pragma: no cover - only available inside Blender
    bpy = None
    bmesh = None

ROOT = Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------------------
# Config loading
# ---------------------------------------------------------------------------
def load_config() -> dict:
    cfg = {}
    for name in ("geometry", "equipment", "network"):
        with (ROOT / "config" / f"{name}.json").open(encoding="utf-8") as fh:
            cfg[name] = json.load(fh)
    return cfg


def parse_args() -> dict:
    argv = sys.argv
    options = {"out": "data/thermalloop.glb"}
    if "--" in argv:
        rest = argv[argv.index("--") + 1:]
        if "--out" in rest:
            options["out"] = rest[rest.index("--out") + 1]
    return options


# ---------------------------------------------------------------------------
# Material + object helpers
# ---------------------------------------------------------------------------
_MATERIALS: dict[str, "bpy.types.Material"] = {}


def material(name: str, color, *, metallic=0.0, roughness=0.6, alpha=1.0, emission=0.0):
    key = f"{name}"
    if key in _MATERIALS:
        return _MATERIALS[key]
    mat = bpy.data.materials.new(name=key)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    bsdf = nodes.get("Principled BSDF")
    if bsdf is None:
        bsdf = next((n for n in nodes if n.type == "BSDF_PRINCIPLED"), None)
    if bsdf is None:
        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        output = next((n for n in nodes if n.type == "OUTPUT_MATERIAL"), None)
        if output is None:
            output = nodes.new("ShaderNodeOutputMaterial")
        mat.node_tree.links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    r, g, b = color

    def set_input(name, value):
        if name in bsdf.inputs:
            bsdf.inputs[name].default_value = value

    set_input("Base Color", (r, g, b, 1.0))
    set_input("Metallic", metallic)
    set_input("Roughness", roughness)
    set_input("Emission Color", (r, g, b, 1.0))
    set_input("Emission Strength", emission)
    if alpha < 1.0:
        set_input("Alpha", alpha)
        try:
            mat.blend_method = "BLEND"
        except (AttributeError, TypeError):
            pass
    _MATERIALS[key] = mat
    return mat


def clear_scene():
    # Headless-safe: remove datablocks directly instead of relying on operators
    # that need a specific UI context.
    for obj in list(bpy.data.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    for block in (bpy.data.meshes, bpy.data.curves, bpy.data.materials,
                  bpy.data.cameras, bpy.data.lights):
        for item in list(block):
            block.remove(item)
    _MATERIALS.clear()


def _new_object(name, mesh, coll):
    obj = bpy.data.objects.new(name, mesh)
    coll.objects.link(obj)
    return obj


def collection(name: str):
    if name in bpy.data.collections:
        return bpy.data.collections[name]
    coll = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(coll)
    return coll


def box(name, center, size, mat, coll):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bm.to_mesh(mesh)
    bm.free()
    obj = _new_object(name, mesh, coll)
    obj.location = tuple(center)
    obj.scale = (size[0], size[1], size[2])
    obj.data.materials.append(mat)
    return obj


def cylinder(name, center, radius, depth, mat, coll, axis="Z"):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cone(
        bm, cap_ends=True, cap_tris=False, segments=24,
        radius1=radius, radius2=radius, depth=depth,
    )
    bm.to_mesh(mesh)
    bm.free()
    obj = _new_object(name, mesh, coll)
    obj.location = tuple(center)
    if axis == "X":
        obj.rotation_euler = (0.0, math.pi / 2.0, 0.0)
    elif axis == "Y":
        obj.rotation_euler = (math.pi / 2.0, 0.0, 0.0)
    obj.data.materials.append(mat)
    return obj


def polyline_tube(name, points, radius, mat, coll):
    curve = bpy.data.curves.new(name=f"{name}_curve", type="CURVE")
    curve.dimensions = "3D"
    spline = curve.splines.new("POLY")
    spline.points.add(len(points) - 1)
    for i, (x, y, z) in enumerate(points):
        spline.points[i].co = (x, y, z, 1.0)
    curve.bevel_depth = radius
    curve.bevel_resolution = 3
    obj = _new_object(name, curve, coll)
    obj.data.materials.append(mat)
    return obj


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------
def build_structure(geom, coll):
    building = geom["main_building"]
    width, depth, height = building["width_x"], building["depth_y"], building["height_z"]

    glass = material("glass_curtain_wall", (0.5, 0.72, 0.81), metallic=0.0, roughness=0.1, alpha=0.25)
    concrete = material("concrete_slab", (0.32, 0.36, 0.4), roughness=0.85)
    steel = material("structural_steel", (0.4, 0.45, 0.5), metallic=0.9, roughness=0.3)

    # Envelope glass walls (thin boxes, not a solid block).
    box("envelope_wall_north", [0, depth / 2, height / 2], [width, 0.12, height], glass, coll)
    box("envelope_wall_south", [0, -depth / 2, height / 2], [width, 0.12, height], glass, coll)
    box("envelope_wall_east", [width / 2, 0, height / 2], [0.12, depth, height], glass, coll)
    box("envelope_wall_west", [-width / 2, 0, height / 2], [0.12, depth, height], glass, coll)
    box("roof_slab", [0, 0, height + 0.12], [width + 0.4, depth + 0.4, 0.24], concrete, coll)

    for floor in geom["floors"]:
        z0, z1 = floor["z"]
        story = z1 - z0
        box(f"slab_{floor['id']}", [0, 0, z0 + 0.14], [width, depth, 0.28], concrete, coll)
        # Structural grid columns, full story height.
        for gx in (-17.3, -8.65, 0.0, 8.65, 17.3):
            for gy in (-10.3, 0.0, 10.3):
                box(
                    f"column_{floor['id']}_{gx:+.0f}_{gy:+.0f}",
                    [gx, gy, z0 + story / 2.0],
                    [0.3, 0.3, story],
                    steel,
                    coll,
                )
        # Edge beams below the ceiling.
        box(f"beam_{floor['id']}_n", [0, 10.75, z1 - 0.22], [width - 0.5, 0.35, 0.35], steel, coll)
        box(f"beam_{floor['id']}_s", [0, -10.75, z1 - 0.22], [width - 0.5, 0.35, 0.35], steel, coll)


def build_gpu_racks(geom, coll):
    layout = geom["gpu_floor_layout"]
    rack = layout["rack_size"]
    per_row = layout["racks_per_row"]
    floor_z = {floor["id"]: floor["z"] for floor in geom["floors"]}
    rack_mat = material("gpu_rack_enclosure", (0.09, 0.12, 0.16), metallic=0.8, roughness=0.3)
    blade_mat = material("gpu_blade", (0.14, 0.22, 0.28), metallic=0.7, roughness=0.35)
    led_mat = material("gpu_led", (0.2, 0.7, 1.0), emission=4.0)
    supply_mat = material("manifold_supply", (0.16, 0.56, 0.91), metallic=0.5, roughness=0.3)
    return_mat = material("manifold_return", (0.9, 0.3, 0.27), metallic=0.5, roughness=0.3)

    for floor_id in ("f1", "f2", "f3"):
        z0 = floor_z[floor_id][0]
        for index in range(12):
            row, col = divmod(index, per_row)
            x = -14.0 + col * (rack["width_x"] + 2.0)
            y = -4.0 + row * 8.0
            z = z0 + 0.35 + rack["height_z"] / 2.0
            rid = f"gpu_{floor_id}_rack_{index + 1:03d}"
            box(rid, [x, y, z], [rack["width_x"], rack["depth_y"], rack["height_z"]], rack_mat, coll)
            for blade in range(9):
                bz = z - rack["height_z"] / 2 + 0.25 + blade * 0.2
                box(f"{rid}_blade_{blade + 1:02d}", [x, y + rack["depth_y"] / 2, bz],
                    [rack["width_x"] * 0.86, 0.04, 0.15], blade_mat, coll)
                box(f"{rid}_led_{blade + 1:02d}", [x - 0.26, y + rack["depth_y"] / 2 + 0.02, bz],
                    [0.07, 0.03, 0.04], led_mat, coll)
            cylinder(f"{rid}_supply_tap", [x + 0.31, y - rack["depth_y"] / 2, z], 0.035, 1.85, supply_mat, coll)
            cylinder(f"{rid}_return_tap", [x - 0.31, y - rack["depth_y"] / 2, z], 0.035, 1.85, return_mat, coll)


def build_marker(obj_cfg, name, size, mat, coll, shape="box"):
    center = obj_cfg["position"]
    if shape == "cylinder":
        cylinder(name, center, size[0] / 2.0, size[2], mat, coll)
    else:
        box(name, center, size, mat, coll)


def build_equipment(equip, coll):
    hx_mat = material("heat_exchanger_plate", (0.46, 0.5, 0.55), metallic=0.85, roughness=0.25)
    pump_mat = material("pump_body", (0.2, 0.5, 0.67), metallic=0.7, roughness=0.3)
    tank_mat = material("tank_buffer", (0.27, 0.56, 0.68), metallic=0.75, roughness=0.3)
    verify_mat = material("tank_verify", (0.48, 0.57, 0.62), metallic=0.75, roughness=0.3)
    valve_mat = material("valve_body", (0.79, 0.63, 0.21), metallic=0.8, roughness=0.25)
    hp_mat = material("heat_pump", (0.6, 0.29, 0.43), metallic=0.7, roughness=0.3)
    cooler_mat = material("dry_cooler", (0.29, 0.35, 0.39), metallic=0.7, roughness=0.3)
    pdu_mat = material("power_distribution", (0.19, 0.23, 0.26), metallic=0.78, roughness=0.3)
    robot_mat = material("robot_arm", (0.96, 0.65, 0.16), metallic=0.6, roughness=0.3)
    seed_mat = material("seed_rack", (0.47, 0.51, 0.56), metallic=0.6, roughness=0.4)
    chamber_mat = material("growth_chamber", (0.83, 0.87, 0.88), metallic=0.5, roughness=0.3)
    sensor_mat = material("sensor", (0.33, 0.85, 0.91), emission=1.5)

    for hx in equip["heat_exchangers"]:
        build_marker(hx, hx["id"], [2.4, 1.2, 2.4], hx_mat, coll)
    for pump in equip["pumps"]:
        build_marker(pump, pump["id"], [0.95, 0.95, 0.75], pump_mat, coll, shape="cylinder")
    for valve in equip["valves"]:
        build_marker(valve, valve["id"], [0.55, 0.55, 0.55], valve_mat, coll)
    for tank in equip["tanks"]:
        mat = tank_mat if tank["type"] == "thermal_buffer" else verify_mat
        size = [3.4, 3.4, 3.2] if tank["type"] == "thermal_buffer" else [2.3, 2.3, 2.8]
        build_marker(tank, tank["id"], size, mat, coll, shape="cylinder")
    build_marker(equip["heat_pump"], equip["heat_pump"]["id"], [2.8, 1.8, 2.2], hp_mat, coll)
    build_marker(equip["dry_cooler"], equip["dry_cooler"]["id"], [5.0, 2.2, 1.4], cooler_mat, coll)
    for pdu in equip.get("power_distribution", []):
        build_marker(pdu, pdu["id"], [1.8, 1.0, 2.4], pdu_mat, coll)
    for robot in equip.get("lab_equipment", []):
        if "robot_arm" in robot["id"]:
            base = robot["position"]
            cylinder(f"{robot['id']}_base", [base[0], base[1], base[2] + 0.15], 0.75, 0.3, robot_mat, coll)
            cylinder(f"{robot['id']}_arm", [base[0], base[1], base[2] + 1.2], 0.25, 1.6, robot_mat, coll)
        else:
            build_marker(robot, robot["id"], [2.2, 2.2, 2.5], robot_mat, coll)
    for seed in equip.get("seed_equipment", []):
        mat = seed_mat if "seed_rack" in seed["id"] else chamber_mat
        build_marker(seed, seed["id"], [2.0, 1.2, 2.5], mat, coll)
    for sensor in equip.get("sensors", []):
        if "position" in sensor:
            build_marker(sensor, sensor["id"], [0.24, 0.24, 0.45], sensor_mat, coll, shape="cylinder")


def build_greenhouse(geom, coll):
    gh = geom["greenhouse"]
    cx, cy = gh["center"][0], gh["center"][1]
    half_w, half_d = gh["width_x"] / 2.0, gh["depth_y"] / 2.0
    eave, peak = 2.35, gh["max_height_z"]
    glass = material("greenhouse_glass", (0.66, 0.88, 0.8), roughness=0.1, alpha=0.22)
    frame = material("greenhouse_frame", (0.54, 0.6, 0.58), metallic=0.8, roughness=0.3)
    soil = material("growing_bed_soil", (0.33, 0.25, 0.18), roughness=0.95)
    plant = material("greenhouse_plant", (0.3, 0.6, 0.25), roughness=0.8)

    box("greenhouse_wall_west", [cx - half_w, cy, eave / 2], [0.1, gh["depth_y"], eave], glass, coll)
    box("greenhouse_wall_east", [cx + half_w, cy, eave / 2], [0.1, gh["depth_y"], eave], glass, coll)
    box("greenhouse_wall_south", [cx, cy - half_d, eave / 2], [gh["width_x"], 0.1, eave], glass, coll)
    box("greenhouse_wall_north", [cx, cy + half_d, eave / 2], [gh["width_x"], 0.1, eave], glass, coll)

    # Arched roof as a half-cylinder scaled to the configured peak.
    roof_mesh = bpy.data.meshes.new("greenhouse_roof")
    bm = bmesh.new()
    bmesh.ops.create_cone(
        bm, cap_ends=False, cap_tris=False, segments=48,
        radius1=half_w, radius2=half_w, depth=gh["depth_y"],
    )
    bm.to_mesh(roof_mesh)
    bm.free()
    roof = _new_object("greenhouse_roof", roof_mesh, coll)
    roof.location = (cx, cy, eave)
    roof.rotation_euler = (math.pi / 2.0, 0.0, 0.0)
    roof.scale = (1.0, 1.0, (peak - eave) / half_w)
    roof.data.materials.append(glass)

    for i in range(6):
        bx = cx - 10.0 + (i % 3) * 10.0
        by = cy - 4.0 + (i // 3) * 8.0
        box(f"bed_greenhouse_{i + 1:03d}", [bx, by, 0.25], [8.0, 6.0, 0.5], soil, coll)
        for p in range(12):
            px = bx - 3.0 + (p % 4) * 2.0
            py = by - 2.0 + (p // 4) * 2.0
            cylinder(f"plant_gh_{i + 1:02d}_{p + 1:02d}", [px, py, 0.75], 0.08, 0.5, plant, coll)


def build_network(network, coll):
    color_by_role = {
        "supply": material("pipe_primary_supply", (0.16, 0.56, 0.91), metallic=0.6, roughness=0.3),
        "return": material("pipe_return", (0.26, 0.83, 0.9), metallic=0.6, roughness=0.3),
        "rejection": material("pipe_rejection", (0.9, 0.3, 0.27), metallic=0.6, roughness=0.3),
        "hx_outlet": material("pipe_heating_supply", (0.94, 0.52, 0.25), metallic=0.6, roughness=0.3),
        "soil_heating": material("pipe_soil_heating", (0.94, 0.52, 0.25), metallic=0.6, roughness=0.3),
        "sidestream": material("pipe_sidestream", (0.26, 0.83, 0.9), metallic=0.6, roughness=0.3),
    }
    default_mat = material("pipe_default", (0.33, 0.38, 0.42), metallic=0.6, roughness=0.35)
    for circuit in network["circuits"].values():
        for segment in circuit.get("segments", []):
            points = segment.get("points")
            if not points or len(points) < 2:
                continue
            mat = color_by_role.get(segment.get("role"), default_mat)
            radius = max(0.03, segment.get("diameter_m", 0.1) / 2.0)
            polyline_tube(segment["id"], points, radius, mat, coll)


def build_utility_corridor(geom, coll):
    corridor = geom["utility_corridor"]
    p0, p1 = corridor["path"]
    cx = (p0[0] + p1[0]) / 2.0
    length = abs(p1[0] - p0[0])
    z0, z1 = corridor["z"]
    concrete = material("corridor_concrete", (0.41, 0.45, 0.48), roughness=0.9)
    box(corridor["id"], [cx, 0.0, (z0 + z1) / 2.0], [length, corridor["width_y"], z1 - z0], concrete, coll)


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------
def export_glb(out: str):
    target = Path(out)
    if not target.is_absolute():
        target = ROOT / out
    target.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.export_scene.gltf(
        filepath=str(target),
        export_format="GLB",
        export_yup=True,
        use_active_collection=False,
        export_apply=True,
    )
    sys.stdout.flush()
    print(f"Exported GLB -> {target} ({target.stat().st_size} bytes)", flush=True)


def build():
    cfg = load_config()
    clear_scene()
    build_structure(cfg["geometry"], collection("structure"))
    build_gpu_racks(cfg["geometry"], collection("gpu_halls"))
    build_equipment(cfg["equipment"], collection("equipment"))
    build_utility_corridor(cfg["geometry"], collection("underground"))
    build_greenhouse(cfg["geometry"], collection("greenhouse"))
    build_network(cfg["network"], collection("hydronics"))

    sun = bpy.data.lights.new("sun", type="SUN")
    sun.energy = 3.0
    sun_obj = bpy.data.objects.new("key_light", sun)
    sun_obj.rotation_euler = (math.radians(55), math.radians(20), math.radians(40))
    bpy.context.scene.collection.objects.link(sun_obj)


def main():
    if bpy is None:
        print("Run inside Blender: blender --background --python blender/build_model.py -- --out data/thermalloop.glb")
        return 1
    options = parse_args()
    build()
    export_glb(options["out"])
    total = sum(1 for obj in bpy.data.objects if obj.type in {"MESH", "CURVE"})
    print(f"Facility objects authored: {total}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
