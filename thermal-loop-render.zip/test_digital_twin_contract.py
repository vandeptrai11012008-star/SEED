"""Requirement-level checks for the upgraded 3D/simulation data contract."""
import math

from thermalloop.config_loader import load_config
from thermalloop.scene import build_scene
from thermalloop.simulation import run_simulation


def test_six_floor_geometry_and_world_scale():
    cfg = load_config()
    geometry = cfg["geometry"]
    assert geometry["units"] == "m"
    assert geometry["world"]["ground_level_z"] == 0.0
    assert [floor["id"] for floor in geometry["floors"]] == ["b2", "b1", "gf", "f1", "f2", "f3"]
    assert [floor["z"] for floor in geometry["floors"]] == [
        [-8.5, -4.0], [-4.0, 0.0], [0.0, 4.5],
        [4.5, 9.0], [9.0, 13.5], [13.5, 18.0],
    ]


def test_building_greenhouse_dimensions_and_separation():
    geometry = load_config()["geometry"]
    building = geometry["main_building"]
    greenhouse = geometry["greenhouse"]
    assert (building["width_x"], building["depth_y"], building["height_z"]) == (36.0, 22.0, 18.0)
    assert (greenhouse["width_x"], greenhouse["depth_y"], greenhouse["max_height_z"]) == (30.0, 18.0, 5.0)
    assert greenhouse["center"] == [41.0, 0.0, 0.0]
    assert greenhouse["footprint"]["x"][0] - building["footprint"]["x"][1] == 8.0
    assert greenhouse["roof"] == "arched"


def test_scene_has_detailed_stable_equipment_ids():
    scene = build_scene(load_config())
    ids = {obj["id"] for obj in scene["objects"]}
    required = {
        "hx_b2_primary_001", "pump_primary_001", "pump_secondary_001",
        "pump_greenhouse_001", "tank_buffer_001", "tank_verify_001",
        "hp_b2_001", "drycooler_roof_001", "robot_arm_gf_001",
        "seed_rack_b1_001", "growth_chamber_b1_001",
        "sensor_seed_storage_T_RH", "sensor_greenhouse_soil_T",
        "zone_robot_lab", "zone_seed_storage", "zone_seed_testing",
        "zone_greenhouse_soil",
    }
    assert required <= ids
    assert scene["counts"]["floors"] == 6
    assert scene["counts"]["gpu_racks"] == 36
    assert scene["counts"]["objects"] >= 90


def test_exactly_two_connected_circuit_contracts_and_renderable_paths():
    cfg = load_config()
    circuits = cfg["network"]["circuits"]
    assert set(circuits) == {"primary", "secondary"}
    assert all(circuit["closed_loop"] for circuit in circuits.values())
    all_segment_ids = set()
    for circuit in circuits.values():
        for segment in circuit["segments"]:
            assert segment["from"] in circuit["nodes"] or segment["from"].startswith("gpu_floor")
            assert segment["to"] in circuit["nodes"] or segment["to"].startswith("gpu_floor")
            assert len(segment["points"]) >= 2
            assert segment["diameter_m"] > 0
            assert segment["length_m"] > 0
            all_segment_ids.add(segment["id"])
    assert {
        "pipe_pri_supply_001", "pipe_pri_return_main_001",
        "pipe_sec_supply_header_001", "pipe_robot_supply_001",
        "pipe_seed_test_supply_001", "pipe_buried_supply_001",
        "pipe_soil_heating_001", "pipe_buried_return_001",
        "pipe_treatment_feed_001", "pipe_treatment_return_001",
    } <= all_segment_ids


def test_simulation_binds_state_to_every_rendered_pipe():
    cfg = load_config()
    scene = build_scene(cfg)
    result = run_simulation({"duration_s": 600, "timestep_s": 600}, cfg)
    step = result["series"][0]
    assert set(step["pipe_states"]) == {pipe["id"] for pipe in scene["pipes"]}
    assert set(step["rack_power_W"]) >= {"gpu_f1_rack_001", "gpu_f2_rack_001", "gpu_f3_rack_001"}
    assert set(step["sensor_states"]) >= {
        "sensor_primary_supply_T", "sensor_secondary_supply_T",
        "sensor_buffer_T", "sensor_greenhouse_soil_T",
        "sensor_seed_storage_T_RH", "sensor_seed_testing_T_RH",
    }


def test_hx_temperature_is_physical_without_heat_pump():
    result = run_simulation({
        "duration_s": 3600,
        "timestep_s": 600,
        "heat_pump_enabled": False,
    })
    for step in result["series"]:
        assert step["hx_secondary_out_C"] <= step["primary_return_C"] + 1e-9
        assert step["secondary_supply_C"] <= max(step["primary_return_C"], step["buffer_temp_C"]) + 1e-9
        assert step["secondary_supply_C"] != 55.0  # no fixed/display-only setpoint


def test_heat_pump_condenser_energy_reconciles():
    result = run_simulation({
        "duration_s": 3600,
        "timestep_s": 600,
        "ambient_mean_C": -20.0,
        "heat_pump_enabled": True,
    })
    for step in result["series"]:
        assert math.isclose(
            step["heat_pump_thermal_W"],
            step["heat_pump_source_W"] + step["heat_pump_elec_W"],
            abs_tol=1e-6,
        )


def test_buffer_really_discharges_and_balances_hold():
    result = run_simulation({
        "duration_s": 86400,
        "timestep_s": 600,
        "ambient_mean_C": -8.0,
        "heat_pump_enabled": False,
    })
    assert max(step["buffer_discharge_W"] for step in result["series"]) > 0.0
    assert all(result["conservation_checks"][name]["passed"] for name in (
        "capture_split", "primary_balance", "secondary_balance"
    ))
    assert result["conservation_checks"]["mass_balance"]["passed"]
