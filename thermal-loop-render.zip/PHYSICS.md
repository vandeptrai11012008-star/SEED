# Physics models

All models are **simplified engineering models**, labeled as such. They are
deterministic — no random values are ever presented as physical predictions.
Units are SI internally (temperature in K unless a name ends in `_C`).

## Core relations (`backend/thermalloop/physics.py`)

- **Sensible heat:** `Q = m_dot · cp · ΔT` and its inverses
  `m_dot = Q / (cp·ΔT)`, `ΔT = Q / (m_dot·cp)`. Guarded against ΔT→0.
- **Heat exchanger:** effectiveness–NTU for a counterflow unit. If a
  manufacturer effectiveness is supplied it is used directly; otherwise ε is
  derived from UA and the stream capacity rates. Energy out of the hot stream
  equals energy into the cold stream (verified in tests).
- **Pump power:** `P = V_dot · Δp / η`.
- **Pipe friction:** Darcy–Weisbach with a Swamee–Jain explicit friction factor
  (laminar `f = 64/Re` below Re = 2300).
- **Buried pipe loss:** linear `Q = U'·L·(T_water − T_soil)` with an effective
  per-length loss coefficient.
- **Thermal tank:** lumped single node, explicit Euler, with standing loss
  `U·(T − T_ambient)`.
- **Greenhouse soil:** lumped node with pipe gain and losses through the cover
  (to air) and to deep ground.
- **Zone demand:** temperature-dependent, scaled by the degree-day ratio and
  clamped to `[0, design_demand]`.
- **Heat pump:** delivers up to a rated thermal output with electrical input
  `Q / COP`.

## Numerical conservation checks

Each timestep and whole run is checked at relative tolerance `1e-6`
(`tests/test_simulation.py` and `tests/test_digital_twin_contract.py`).

1. **Capture split:** `IT_generated = liquid_captured + air_remaining`.
2. **Primary circuit:**
   `liquid_captured = primary_pipe_loss + hx_transfer + heat_pump_source
    + aux_rejected + primary_unrejected`.
3. **Secondary circuit including storage:**
   `hx_transfer + heat_pump_condenser = delivered + distribution_losses
    + secondary_rejected + buffer_energy_change + tank_standing_loss`.
4. **Mass:** closed-loop supply and return mass-flow residuals are reported and
   checked independently.

Heat-pump condenser heat is constrained by `Q_cond = Q_source + P_compressor`;
source extraction is deducted from the primary loop. Pump flow, heat-pump output
and dry-cooler rejection are rating-limited. Buffer charge and discharge are
separate quantities, so stored heat actually serves demand when direct recovery
is insufficient. Every rendered pipe ID receives calculated mass flow and water
temperature in `pipe_states`.

These are numerical control-volume closure checks, not experimental calibration
or certification against manufacturer/plant measurements.

## Design point sanity check

At 100% load with the defaults (1500 kW IT, 0.80 capture):
`liquid_captured = 1200 kW`, `air_remaining = 300 kW` — matching the
specification. Verified by `test_full_load_numbers_match_spec`.

## Known simplifications

- Single-node buffer tank, zone-air nodes and greenhouse soil node (no tank
  stratification or multidimensional conduction).
- Diurnal sinusoidal weather and GPU load drivers (replaceable by EPW + traces).
- Indoor pipe heat loss represented by configured fractions; buried loss uses a
  steady per-length coefficient to deep soil.
- Steady per-timestep HX effectiveness and quasi-steady Darcy-Weisbach hydraulics
  rather than full component transients.

Replace any of these with the OpenModelica / EnergyPlus couplings for higher
fidelity; the config and identifiers are shared so the swap is localized.
