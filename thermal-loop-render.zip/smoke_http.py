"""Live HTTP smoke test against a running server (python run_server.py).

Run: python tests/smoke_http.py
"""
import json
import sys
import urllib.request

BASE = "http://127.0.0.1:8000"


def get(path):
    with urllib.request.urlopen(BASE + path, timeout=10) as r:
        return r.status, json.loads(r.read())


def post(path, payload):
    data = json.dumps(payload).encode()
    req = urllib.request.Request(BASE + path, data=data,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.status, json.loads(r.read())


def main():
    out = {}
    s, h = get("/api/health"); out["health"] = (s, h["status"])
    s, c = get("/api/config"); out["config_keys"] = sorted(c.keys())
    s, sc = get("/api/scene"); out["scene_counts"] = sc["counts"]
    s, st = get("/api/state"); out["state_measured"] = st["is_measured_data"]
    s, sim = post("/api/simulate", {"mode": "simplified_physics", "scenario_id": "winter_peak"})
    out["sim_run_id"] = sim["run_id"]
    out["sim_measured"] = sim["is_measured_data"]
    out["sim_checks_pass"] = all(
        sim["conservation_checks"][k]["passed"]
        for k in ("capture_split", "primary_balance", "secondary_balance")
    )
    out["sim_summary"] = sim["summary"]
    s, res = get(f"/api/results/{sim['run_id']}"); out["results_roundtrip"] = res["run_id"] == sim["run_id"]
    print(json.dumps(out, indent=2))
    assert out["health"] == (200, "ok")
    assert out["sim_checks_pass"]
    assert out["sim_measured"] is False
    assert out["results_roundtrip"]
    print("SMOKE_OK")


if __name__ == "__main__":
    sys.exit(main())
