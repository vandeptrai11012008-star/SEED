# ThermalLoop setup script (Windows PowerShell).
# Installs backend Python dependencies and verifies imports.
$ErrorActionPreference = "Stop"
Write-Host "ThermalLoop setup" -ForegroundColor Cyan

$root = Split-Path -Parent $PSScriptRoot

Write-Host "Installing backend Python dependencies..."
python -m pip install fastapi uvicorn pydantic httpx pytest

Write-Host "Verifying backend imports..."
python -c "import fastapi, uvicorn, pydantic, httpx, pytest; print('backend deps OK')"

Write-Host "Running backend tests..."
python -m pytest "$root\tests" -q

Write-Host ""
Write-Host "Backend ready. Next:" -ForegroundColor Green
Write-Host "  ./scripts/run_backend.ps1"
Write-Host "  cd frontend; & 'C:\Program Files\nodejs\npm.cmd' install; & 'C:\Program Files\nodejs\npm.cmd' run dev"
