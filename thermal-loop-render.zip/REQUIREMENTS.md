# Requirements & engineering assumptions

## Geometry (config/geometry.json)
- World unit = 1 meter. Axes: X east, Y north, Z up. Ground at Z = 0.
- Main building 36 (X) × 22 (Y) × 18 m (Z), footprint X[-18,18], Y[-11,11].
- Floors: B2 [-8.5,-4.0] plant/HX, B1 [-4.0,0] seed, GF [0,4.5] robot lab,
  1F/2F/3F GPU data center in 4.5 m lifts to 18 m.
- Greenhouse 30 × 18 × 5 m centered at (41,0,0), 8 m gap from the main building.
- Underground utility corridor carries buried insulated pipe between them.

## Power (config/assumptions.json)
- Total nominal IT power 1500 kW; 500 kW per GPU floor (12 racks × 41.667 kW).
- Liquid capture fraction 0.80 → captured 1200 kW, remaining 300 kW at full load.
- Every value is configurable via config or the `/api/simulate` request.
- The model does **not** assume all captured heat is delivered: HX effectiveness,
  distribution losses, demand, storage, and rejection are modeled separately.

## Hydronic architecture
- Two hydraulically isolated closed circuits coupled only at `hx_b2_primary_001`.
- Primary: blue supply manifold → GPU floors → red hot risers → HX → cooled
  water back to GPU supply; pumps, isolation + modulating valves, aux rejection.
- Secondary: HX → buffer tank → parallel controllable branches (robot lab, B1
  seed zones, greenhouse via buried pipe) with mixing valves; return to HX.
- Water treatment is a closed-loop sidestream (`tank_verify_001`), not an open
  tank interrupting the pressurized loop.
- Heat pump (`hp_b2_001`) optionally upgrades temperature / rejects surplus.

## Stable identifiers (config contract)
Floors, racks (`gpu_f{1,2,3}_rack_NNN`), pumps (`pump_*_001`), valves
(`valve_*`), pipe segments (`pipe_*`), heat exchanger (`hx_b2_primary_001`),
tanks (`tank_buffer_001`, `tank_verify_001`), zones (`zone_robot_lab`,
`zone_seed_storage`, `zone_seed_testing`, `zone_greenhouse_soil`), and sensors
(`sensor_*`). These match across 3D objects, API responses, and outputs.

## Software
- Frontend: React + TypeScript + Three.js / React Three Fiber.
- Backend: Python + FastAPI with Pydantic schemas.
- Simulation: Python baseline + OpenModelica/EnergyPlus adapters + optimization.
- 3D authoring: Blender Python API → GLB.
- Exchangeable backend so the UI runs on the deterministic reduced-order baseline while external
  solver couplings are developed. External tools are never claimed to run unless
  actually executed locally.

## Non-negotiables
- SI units internally; conservation of mass and energy enforced and tested.
- No random or fabricated values presented as predictions; no demonstration
  results labeled as measured data.
- Simplified models are clearly labeled where exact equipment data is absent.
