# Capture deterministic headless screenshots of the major camera presets.
# Backend and frontend dev servers must already be running.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$chromeCandidates = @(
  "C:\Program Files\Google\Chrome\Application\chrome.exe",
  "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
)
$browser = $chromeCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $browser) { throw "Chrome or Edge was not found." }

$views = @(
  @{ Name = "front-cutaway"; Url = "http://127.0.0.1:5173/?view=front_cutaway" },
  @{ Name = "greenhouse"; Url = "http://127.0.0.1:5173/?view=greenhouse" },
  @{ Name = "underground"; Url = "http://127.0.0.1:5173/?view=underground" },
  @{ Name = "floor-f2"; Url = "http://127.0.0.1:5173/?view=floor&floor=f2" }
)

foreach ($view in $views) {
  $output = "$root\data\view-$($view.Name).png"
  $profile = "$env:TEMP\thermalloop-headless-$($view.Name)-$PID"
  $arguments = @(
    "--headless=new", "--no-first-run", "--disable-extensions",
    "--ignore-gpu-blocklist", "--enable-webgl", "--use-angle=swiftshader",
    "--window-size=1600,1000", "--virtual-time-budget=12000",
    "--user-data-dir=$profile", "--screenshot=$output", $view.Url
  )
  Start-Process -FilePath $browser -ArgumentList $arguments -Wait
  if (-not (Test-Path $output)) { throw "Screenshot failed: $($view.Name)" }
  Write-Host "Captured $output"
}
