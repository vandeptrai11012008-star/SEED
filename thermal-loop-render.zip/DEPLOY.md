# Deploying ThermalLoop (frontend + backend)

Full-stack deploy: FastAPI backend on **Render**, React/Three.js frontend on
**Vercel**. Both have free tiers and pull from GitHub.

Config files already in the repo:
- `render.yaml` — Render backend blueprint (`rootDir: backend`, `python serve.py`).
- `backend/serve.py` — production entrypoint (binds `0.0.0.0`, reads `$PORT`).
- `vercel.json` — Vercel frontend config (`rootDirectory: frontend`, Vite).
- `frontend/.env.example` — documents the `VITE_API_BASE` variable.

The frontend API client (`frontend/src/api/client.ts`) uses `VITE_API_BASE`:
empty in dev (Vite proxies `/api` to localhost), set to the backend URL in prod.

## 0. Push the repo to GitHub (one time)

Git is required. Install from https://git-scm.com/download/win , then:

```powershell
cd C:\Users\vande\thermal-loop
git init
git add .
git commit -m "ThermalLoop AI Center digital twin"
git branch -M main
git remote add origin https://github.com/<you>/thermal-loop.git
git push -u origin main
```

## 1. Backend on Render

1. Go to https://render.com , sign in with GitHub.
2. **New +** -> **Blueprint** -> select the `thermal-loop` repo.
3. Render reads `render.yaml` and creates the `thermalloop-backend` web service.
4. Click **Apply** / **Deploy**. Wait for the build to finish (free tier is slow
   on first boot and sleeps when idle).
5. Verify: open `https://<your-service>.onrender.com/api/health` -> should return
   `{"status":"ok", ...}`.
6. Copy the service URL (e.g. `https://thermalloop-backend.onrender.com`).

## 2. Frontend on Vercel

1. Go to https://vercel.com , sign in with GitHub.
2. **Add New...** -> **Project** -> import the `thermal-loop` repo.
3. Set **Root Directory** to `frontend` (vercel.json also declares this).
   Framework preset: **Vite**. Build: `npm run build`. Output: `dist`.
4. Under **Environment Variables** add:
   - `VITE_API_BASE` = `https://<your-service>.onrender.com`  (no trailing slash)
5. **Deploy**. Open the Vercel URL -> the 3D twin loads and the dashboards call
   the Render backend.

## 3. After deploy

- Changing `VITE_API_BASE` requires a **redeploy** on Vercel (env vars are baked
  in at build time for Vite).
- The backend already sends permissive CORS (`allow_origins=["*"]`), so the
  Vercel origin can call it. To lock it down later, restrict origins in
  `backend/thermalloop/app.py`.
- Render free tier sleeps after inactivity; the first request after idle takes
  ~30-60 s to wake. Upgrade the plan to avoid cold starts.

## Alternatives

- **Railway** (`railway.app`) works the same way for the backend: set root to
  `backend`, start command `python serve.py`.
- **Netlify** can host the frontend instead of Vercel: base directory `frontend`,
  build `npm run build`, publish `frontend/dist`, env `VITE_API_BASE`.
- A single-host option: serve the built `frontend/dist` as static files from
  FastAPI and deploy only the backend. Not configured here; ask if you want it.
