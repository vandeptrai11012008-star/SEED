"""Validate a binary glTF (GLB) without external dependencies.

Checks the magic header, parses the JSON chunk, and reports node/mesh counts and
whether the stable ThermalLoop engineering identifiers are present.

Usage: python tests/inspect_glb.py data/thermalloop.glb
"""
from __future__ import annotations

import json
import struct
import sys
from pathlib import Path

REQUIRED_IDS = [
    "slab_b2", "slab_f3", "greenhouse_roof",
    "gpu_f1_rack_001", "gpu_f3_rack_012",
    "hx_b2_primary_001", "pump_primary_001", "tank_buffer_001", "tank_verify_001",
    "hp_b2_001", "drycooler_roof_001",
    "robot_arm_gf_001", "seed_rack_b1_001", "growth_chamber_b1_001",
    "bed_greenhouse_001", "pipe_pri_supply_001", "pipe_buried_supply_001",
]


def main() -> None:
    path = Path(sys.argv[1] if len(sys.argv) > 1 else "data/thermalloop.glb")
    data = path.read_bytes()
    magic, version, length = struct.unpack_from("<4sII", data, 0)
    assert magic == b"glTF", f"Not a GLB file: {magic!r}"
    assert version == 2, f"Unexpected glTF version: {version}"
    assert length == len(data), "GLB length header does not match file size"

    # First chunk must be JSON.
    chunk_len, chunk_type = struct.unpack_from("<I4s", data, 12)
    assert chunk_type == b"JSON", f"First chunk is not JSON: {chunk_type!r}"
    gltf = json.loads(data[20:20 + chunk_len].decode("utf-8"))

    node_names = {node.get("name", "") for node in gltf.get("nodes", [])}
    mesh_count = len(gltf.get("meshes", []))
    missing = [identifier for identifier in REQUIRED_IDS if identifier not in node_names]

    report = {
        "file": str(path),
        "size_bytes": len(data),
        "glb_version": version,
        "node_count": len(gltf.get("nodes", [])),
        "mesh_count": mesh_count,
        "material_count": len(gltf.get("materials", [])),
        "required_ids_present": not missing,
        "missing_ids": missing,
    }
    print(json.dumps(report, indent=2))
    assert not missing, f"GLB is missing required identifiers: {missing}"
    print("GLB_OK")


if __name__ == "__main__":
    main()
