"""API contract tests using FastAPI TestClient."""
from fastapi.testclient import TestClient

from thermalloop.app import app

client = TestClient(app)


def test_health():
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_config():
    r = client.get("/api/config")
    assert r.status_code == 200
    body = r.json()
    for key in ("units", "site", "geometry", "equipment", "network", "assumptions", "simulation"):
        assert key in body


def test_scene_ids_match_contract():
    r = client.get("/api/scene")
    assert r.status_code == 200
    scene = r.json()
    ids = {o["id"] for o in scene["objects"]}
    assert "gpu_f1_rack_001" in ids
    assert "hx_b2_primary_001" in ids
    assert "tank_buffer_001" in ids
    assert "tank_verify_001" in ids
    assert scene["counts"]["gpu_racks"] == 36


def test_state():
    r = client.get("/api/state")
    assert r.status_code == 200
    assert r.json()["is_measured_data"] is False


def test_simulate_and_fetch_results():
    r = client.post("/api/simulate", json={"mode": "simplified_physics", "duration_s": 3600, "timestep_s": 600})
    assert r.status_code == 200
    body = r.json()
    run_id = body["run_id"]
    assert body["is_measured_data"] is False
    assert body["conservation_checks"]["secondary_balance"]["passed"]

    r2 = client.get(f"/api/results/{run_id}")
    assert r2.status_code == 200
    assert r2.json()["run_id"] == run_id


def test_simulate_named_scenario():
    r = client.post("/api/simulate", json={"mode": "simplified_physics", "scenario_id": "winter_peak", "duration_s": 3600, "timestep_s": 600})
    assert r.status_code == 200


def test_unknown_scenario_404():
    r = client.post("/api/simulate", json={"scenario_id": "does_not_exist"})
    assert r.status_code == 404


def test_unknown_run_id_404():
    r = client.get("/api/results/run_nope")
    assert r.status_code == 404
