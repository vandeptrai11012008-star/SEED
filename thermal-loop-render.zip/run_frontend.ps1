# Start the ThermalLoop Vite dev server.
# Uses npm.cmd directly to avoid PowerShell execution-policy issues with npm.ps1.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$npm = "C:\Program Files\nodejs\npm.cmd"
Set-Location "$root\frontend"
if (-not (Test-Path "node_modules")) {
  Write-Host "Installing frontend dependencies..." -ForegroundColor Cyan
  & $npm install
}
Write-Host "Starting frontend on http://localhost:5173" -ForegroundColor Cyan
& $npm run dev
