"""Generate an OpenModelica (.mo) model of the two-circuit hydronic loop.

This adapter writes a Modelica source file parameterized from the shared config.
It does NOT run OpenModelica. To simulate locally (OpenModelica installed):

    omc modelica/run_openmodelica.mos

or load modelica/ThermalLoop.mo in OMEdit and simulate.

The backend only labels results as 'openmodelica' after a real OM run is loaded.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_assumptions() -> dict:
    with (ROOT / "config" / "assumptions.json").open(encoding="utf-8") as fh:
        return json.load(fh)


MODEL_TEMPLATE = """model ThermalLoop
  // Auto-generated from config/assumptions.json. Simplified lumped model.
  // Two closed circuits coupled by a heat exchanger (effectiveness model).
  parameter Real cp = {cp} "water specific heat [J/(kg.K)]";
  parameter Real it_power = {it_power} "total IT power [W]";
  parameter Real capture = {capture} "liquid capture fraction [-]";
  parameter Real hx_eff = {hx_eff} "heat exchanger effectiveness [-]";
  parameter Real m_pri = {m_pri} "primary mass flow [kg/s]";
  parameter Real m_sec = {m_sec} "secondary mass flow [kg/s]";
  parameter Real tank_mass = {tank_mass} "buffer tank water mass [kg]";
  parameter Real tank_loss = {tank_loss} "tank standing loss [W/K]";
  parameter Real amb = {amb} "ambient temperature [K]";

  Real q_liquid "captured liquid heat [W]";
  Real q_hx "heat transferred by HX [W]";
  Real T_buffer(start = {tank_start}) "buffer tank temperature [K]";
equation
  q_liquid = it_power * capture;
  // effectiveness model: transferred heat limited by effectiveness and flows
  q_hx = hx_eff * q_liquid;
  // buffer tank energy balance (charge from HX, standing loss to ambient)
  tank_mass * cp * der(T_buffer) = q_hx - tank_loss * (T_buffer - amb);
annotation(experiment(StartTime = 0, StopTime = 86400, Interval = 600));
end ThermalLoop;
"""

RUN_MOS = """// OpenModelica script: load and simulate the generated model.
loadFile("ThermalLoop.mo");
simulate(ThermalLoop, stopTime = 86400, numberOfIntervals = 144, outputFormat = "csv");
getErrorString();
"""


def generate() -> Path:
    a = load_assumptions()
    cp = a["primary_circuit"]["cp_J_per_kgK"]
    it_power = a["power"]["total_it_power_kW"] * 1000.0
    capture = a["power"]["liquid_capture_fraction"]
    pri_dT = a["primary_circuit"]["design_delta_T_K"]
    sec_dT = a["secondary_circuit"]["design_delta_T_K"]
    q_liquid = it_power * capture
    m_pri = q_liquid / (cp * pri_dT)
    m_sec = q_liquid / (cp * sec_dT)
    tank = a["thermal_buffer"]
    tank_mass = a["primary_circuit"]["density_kg_per_m3"] * tank["volume_m3"]

    model = MODEL_TEMPLATE.format(
        cp=cp,
        it_power=it_power,
        capture=capture,
        hx_eff=a["heat_exchanger"]["effectiveness"],
        m_pri=round(m_pri, 4),
        m_sec=round(m_sec, 4),
        tank_mass=round(tank_mass, 2),
        tank_loss=tank["heat_loss_W_per_K"],
        amb=283.15,
        tank_start=round(tank["initial_temp_C"] + 273.15, 2),
    )
    mo_path = ROOT / "modelica" / "ThermalLoop.mo"
    mo_path.write_text(model, encoding="utf-8")
    (ROOT / "modelica" / "run_openmodelica.mos").write_text(RUN_MOS, encoding="utf-8")
    return mo_path


if __name__ == "__main__":
    p = generate()
    print(f"Generated Modelica model -> {p}")
    print("Run locally with: omc modelica/run_openmodelica.mos")
