"""Live integration smoke check for the upgraded scene and physics binding.

Start backend/frontend, then optionally set:
  THERMALLOOP_API=http://127.0.0.1:8001
  THERMALLOOP_WEB=http://127.0.0.1:5173
"""
from __future__ import annotations

import json
import os
import urllib.request

API = os.environ.get("THERMALLOOP_API", "http://127.0.0.1:8000")
WEB = os.environ.get("THERMALLOOP_WEB", "http://127.0.0.1:5173")


def read_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=20) as response:
        return json.loads(response.read())


def main() -> None:
    with urllib.request.urlopen(WEB, timeout=20) as response:
        page = response.read().decode("utf-8")
    scene = read_json(f"{API}/api/scene")
    request = urllib.request.Request(
        f"{API}/api/simulate",
        data=json.dumps({"duration_s": 3600, "timestep_s": 600}).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        run = json.loads(response.read())

    first = run["series"][0]
    checks = run["conservation_checks"]
    report = {
        "frontend_served": "ThermalLoop AI Center" in page,
        "scene_counts": scene["counts"],
        "pipe_paths_renderable": all(len(pipe.get("points", [])) >= 2 for pipe in scene["pipes"]),
        "simulation_steps": run["n_steps"],
        "all_balances_pass": all(
            value["passed"] for value in checks.values()
            if isinstance(value, dict) and "passed" in value
        ),
        "pipe_state_binding_complete": set(first["pipe_states"]) == {pipe["id"] for pipe in scene["pipes"]},
        "rack_state_count": len(first["rack_power_W"]),
        "mode": run["mode"],
        "is_measured_data": run["is_measured_data"],
    }
    print(json.dumps(report, indent=2))
    assert report["frontend_served"]
    assert report["scene_counts"]["floors"] == 6
    assert report["scene_counts"]["gpu_racks"] == 36
    assert report["pipe_paths_renderable"]
    assert report["all_balances_pass"]
    assert report["pipe_state_binding_complete"]
    assert report["rack_state_count"] == 36
    assert report["mode"] == "simplified_physics"
    assert report["is_measured_data"] is False
    print("UPGRADE_SMOKE_OK")


if __name__ == "__main__":
    main()
