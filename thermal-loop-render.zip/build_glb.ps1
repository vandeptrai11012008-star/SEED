# Author the full facility in Blender, export GLB, validate it, and publish it
# to the frontend public assets for the "Blender GLB" viewer toggle.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot

$blenderCandidates = Get-ChildItem `
  "C:\Program Files\Blender Foundation\Blender*\blender.exe",
  "C:\Program Files\Blender*\blender.exe" -ErrorAction SilentlyContinue
$blender = $blenderCandidates | Select-Object -First 1
if (-not $blender) { throw "Blender was not found. Install Blender or edit this script's path." }

$glb = Join-Path $root "data\thermalloop.glb"
Write-Host "Authoring facility with $($blender.FullName)" -ForegroundColor Cyan
& $blender.FullName --background --factory-startup `
  --python (Join-Path $root "blender\build_model.py") -- --out $glb
if (-not (Test-Path $glb)) { throw "GLB export failed." }

Write-Host "Validating GLB structure and identifiers" -ForegroundColor Cyan
python (Join-Path $root "tests\inspect_glb.py") $glb

$public = Join-Path $root "frontend\public"
New-Item -ItemType Directory -Force -Path $public | Out-Null
Copy-Item $glb (Join-Path $public "thermalloop.glb") -Force
Write-Host "Published GLB to frontend/public. Enable 'Blender GLB' in the viewer." -ForegroundColor Green
