# Generate the full-scale facility in Blender, save the editable .blend, and
# export the GLB into frontend/public/models/. Backend/frontend not required.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot

$blender = Get-ChildItem `
  "C:\Program Files\Blender Foundation\Blender*\blender.exe",
  "C:\Program Files\Blender*\blender.exe" -ErrorAction SilentlyContinue |
  Select-Object -First 1
if (-not $blender) { throw "Blender not found. Install Blender or edit this path." }

Write-Host "Authoring ThermalLoop facility with $($blender.FullName)" -ForegroundColor Cyan
& $blender.FullName --background --factory-startup `
  --python (Join-Path $root "blender\generate_facility.py")

$glb = Join-Path $root "frontend\public\models\thermal_loop.glb"
if (-not (Test-Path $glb)) { throw "GLB export failed." }
Write-Host "Validating exported GLB" -ForegroundColor Cyan
python (Join-Path $root "tests\inspect_glb.py") $glb
Write-Host "Done. Editable: blender/thermal_loop.blend  GLB: frontend/public/models/thermal_loop.glb" -ForegroundColor Green
