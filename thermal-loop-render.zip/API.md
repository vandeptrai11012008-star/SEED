# ThermalLoop API

Base URL (dev): `http://127.0.0.1:8000`. Interactive OpenAPI docs: `/docs`.
All engineering data is SI internally. Results are never labeled as measured
data; `is_measured_data` is always `false` for generated results.

## GET /api/health
Liveness probe.
```json
{ "status": "ok", "service": "thermalloop-backend", "version": "0.1.0" }
```

## GET /api/config
Returns the merged shared configuration contract: `units`, `site`, `geometry`,
`equipment`, `network`, `assumptions`, `simulation`.

## GET /api/scene
Procedural scene for the 3D viewer. Every object carries a stable `id` that
matches `equipment.json`, `network.json`, and simulation outputs.
```json
{
  "site_id": "thermalloop_ai_center",
  "objects": [ { "id": "gpu_f1_rack_001", "kind": "gpu_rack", "center": [...], "size": [...] } ],
  "pipes":   [ { "id": "pipe_pri_supply_001", "circuit": "primary", "color": "blue" } ],
  "counts":  { "objects": 98, "pipes": 33, "gpu_racks": 36, "floors": 6, "sensors": 8 }
}
```

## GET /api/state
Snapshot: runs a short baseline and returns the last timestep plus a summary.

## POST /api/simulate
Run a simulation. Body (`SimulationRequest`, all fields optional):
```json
{
  "mode": "simplified_physics",
  "scenario_id": "winter_peak",
  "duration_s": 86400,
  "timestep_s": 600,
  "total_it_power_kW": 1500,
  "liquid_capture_fraction": 0.8,
  "gpu_load_base_fraction": 0.55,
  "gpu_load_peak_fraction": 0.95,
  "ambient_mean_C": 10,
  "heat_pump_enabled": true,
  "aux_rejection_enabled": true,
  "overrides": { "controls.heat_pump_enabled": false }
}
```
Response (`SimulationResult`) includes `run_id`, `mode`, `is_measured_data`,
`series` (per-timestep records), `energy_totals_J` / `energy_totals_kWh`,
`conservation_checks`, and `summary`. Each timestep also exposes calculated
`pipe_states` keyed by the exact scene pipe ID (`temperature_C`,
`mass_flow_kg_s`), `sensor_states`, `rack_power_W`, zone demand/delivery/unmet
heat and zone temperature, HX inlet/outlet temperatures, buffer charge/discharge,
pressure losses, and pump/heat-pump electricity.

`mode` is one of `simplified_physics`, `openmodelica`, `energyplus`, `coupled`.
Only `simplified_physics` executes in-process; the external modes return
`executed: false` with instructions, never fabricated results.

### Conservation checks
```json
{
  "capture_split":      { "lhs_J": ..., "rhs_J": ..., "relative_error": 0.0, "passed": true },
  "primary_balance":    { ... "passed": true },
  "secondary_balance":  { ... "passed": true }
}
```

## GET /api/results/{run_id}
Fetch a previously stored run. 404 if unknown. Runs are also persisted to
`results/run_*.json`.
