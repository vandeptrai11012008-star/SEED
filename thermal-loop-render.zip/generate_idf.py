"""Generate a minimal EnergyPlus IDF snippet for the building thermal zones.

This adapter writes an IDF fragment with the ThermalLoop thermal zones and their
design heating loads from config. It does NOT run EnergyPlus. To run locally
(EnergyPlus installed), combine with a full IDF (geometry, materials, an EPW
weather file) and execute:

    energyplus -w <weather.epw> -d energyplus/out energyplus/thermalloop.idf

The backend only labels results 'energyplus' after a real E+ run is parsed.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

ZONE_TEMPLATE = """! Zone: {zone_id}  (design heating {kw} kW, setpoint {sp} C)
Zone,
  {zone_id},               !- Name
  0, 0, 0, 0,              !- Direction/Origin
  1, 1;                    !- Multiplier / Ceiling Height (placeholders)

ZoneControl:Thermostat,
  {zone_id}_Thermostat,    !- Name
  {zone_id},               !- Zone or ZoneList Name
  {zone_id}_Schedule,      !- Control Type Schedule Name
  ThermostatSetpoint:SingleHeating,
  {zone_id}_Heating;       !- Control Object Name

ThermostatSetpoint:SingleHeating,
  {zone_id}_Heating,       !- Name
  {zone_id}_SetpointSched; !- Setpoint Temperature Schedule Name
"""


def generate() -> Path:
    with (ROOT / "config" / "assumptions.json").open(encoding="utf-8") as fh:
        a = json.load(fh)
    parts = [
        "Version, 24.1;",
        "! Auto-generated thermal-zone fragment from config/assumptions.json.",
        "! Combine with a full IDF (geometry/materials) + EPW weather to run.",
        "",
    ]
    for zid, z in a["zones"].items():
        parts.append(
            ZONE_TEMPLATE.format(
                zone_id=zid, kw=z["design_heat_demand_kW"], sp=z["setpoint_C"]
            )
        )
    idf = "\n".join(parts)
    out = ROOT / "energyplus" / "thermalloop.idf"
    out.write_text(idf, encoding="utf-8")
    return out


if __name__ == "__main__":
    p = generate()
    print(f"Generated IDF fragment -> {p}")
    print("Run locally with: energyplus -w <weather.epw> -d energyplus/out energyplus/thermalloop.idf")
