"""Unit tests for the core physics primitives."""
import math

from thermalloop import physics as phys


def test_c_k_roundtrip():
    assert math.isclose(phys.k_to_c(phys.c_to_k(25.0)), 25.0, abs_tol=1e-9)


def test_sensible_heat_and_inverse():
    # 1 kg/s water, cp 4186, dT 15 K -> 62790 W
    q = phys.sensible_heat_W(1.0, 4186.0, 15.0)
    assert math.isclose(q, 62790.0, rel_tol=1e-9)
    m = phys.mass_flow_for_heat(q, 4186.0, 15.0)
    assert math.isclose(m, 1.0, rel_tol=1e-9)


def test_mass_flow_guard_on_zero_dt():
    assert phys.mass_flow_for_heat(1000.0, 4186.0, 0.0) == 0.0


def test_delta_T_for_heat():
    dt = phys.delta_T_for_heat(62790.0, 1.0, 4186.0)
    assert math.isclose(dt, 15.0, rel_tol=1e-9)


def test_hx_effectiveness_override_energy_balance():
    r = phys.heat_exchanger_eps_ntu(
        hot_in_K=phys.c_to_k(45), cold_in_K=phys.c_to_k(40),
        m_hot=19.1, m_cold=19.1, cp_hot=4186, cp_cold=4186,
        ua_W_per_K=90000, effectiveness_override=0.85,
    )
    # energy leaving hot equals energy entering cold
    q_hot = 19.1 * 4186 * (phys.c_to_k(45) - r.hot_out_K)
    q_cold = 19.1 * 4186 * (r.cold_out_K - phys.c_to_k(40))
    assert math.isclose(q_hot, r.q_W, rel_tol=1e-6)
    assert math.isclose(q_cold, r.q_W, rel_tol=1e-6)
    assert r.effectiveness == 0.85


def test_hx_ntu_bounds():
    r = phys.heat_exchanger_eps_ntu(
        hot_in_K=phys.c_to_k(45), cold_in_K=phys.c_to_k(40),
        m_hot=19.1, m_cold=19.1, cp_hot=4186, cp_cold=4186,
        ua_W_per_K=90000,
    )
    assert 0.0 <= r.effectiveness <= 1.0
    assert r.q_W >= 0.0


def test_pump_power():
    # 0.02 m3/s, 180 kPa, eta 0.7 -> 5142.8 W
    p = phys.pump_electrical_power_W(0.02, 180000.0, 0.7)
    assert math.isclose(p, 0.02 * 180000.0 / 0.7, rel_tol=1e-9)


def test_pipe_pressure_loss_positive_and_monotonic():
    low = phys.pipe_pressure_loss_Pa(5.0, 0.1, 20.0)
    high = phys.pipe_pressure_loss_Pa(10.0, 0.1, 20.0)
    assert high > low > 0.0


def test_buried_pipe_loss_sign():
    # hot water in cold soil loses heat (positive)
    q = phys.buried_pipe_heat_loss_W(phys.c_to_k(55), phys.c_to_k(9), 0.35, 60.0)
    assert q > 0.0


def test_tank_charges_and_cools():
    hot = phys.tank_temperature_step(phys.c_to_k(45), 50000, 0, phys.c_to_k(10), 50, 600)
    assert hot > phys.c_to_k(45)  # net charge raises temp
    cold = phys.tank_temperature_step(phys.c_to_k(45), 0, 0, phys.c_to_k(10), 50, 600)
    assert cold < phys.c_to_k(45)  # standing loss cools it


def test_zone_demand_clamped():
    # ambient warmer than setpoint -> zero demand
    d = phys.zone_heat_demand_W(100000, phys.c_to_k(21), phys.c_to_k(30))
    assert d == 0.0
    # very cold -> near design
    d2 = phys.zone_heat_demand_W(100000, phys.c_to_k(21), phys.c_to_k(-10))
    assert 0.0 < d2 <= 100000


def test_heat_pump_cop():
    r = phys.heat_pump_upgrade(100000, 4.0, 400000)
    assert math.isclose(r.electrical_in_W, 25000.0, rel_tol=1e-9)
    assert r.thermal_out_W == 100000.0
